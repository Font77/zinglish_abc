var SEVEN_0 = 160;
var SEVEN_1 = 249;
var SEVEN_2 = 146;
var SEVEN_3 = 208;
var SEVEN_4 = 201;
var SEVEN_5 = 196;
var SEVEN_6 = 132;
var SEVEN_7 = 241;
var SEVEN_8 = 128;
var SEVEN_9 = 193;
var A_7 = 129;
var a_7 = 144;
var b_7 = 140;
var B_7 = 140;
var c_7 = 158;
var C_7 = 166;
var d_7 = 152;
var D_7 = 152;
var e_7 = 130;
var E_7 = 134;
var F_7 = 135;
var f_7 = 135;
var G_7 = 164;
var g_7 = 164;
var H_7 = 137;
var h_7 = 141;
var I_7 = 192;
var i_7 = 192;
var J_7 = 184;
var j_7 = 184;
var K_7 = 143;
var k_7 = 143;
var L_7 = 174;
var l_7 = 174;
var M_7 = 161;
var m_7 = 161;
var n_7 = 157;
var N_7 = 157;
var o_7 = 156;
var O_7 = 160;
var P_7 = 131;
var p_7 = 131;
var q_7 = 193;
var Q_7 = 193;
var r_7 = 159;
var R_7 = 146;
var S_7 = 196;
var s_7 = 196;
var t_7 = 142;
var T_7 = 142;
var u_7 = 188;
var U_7 = 188;
var V_7 = 168;
var v_7 = 168;
var W_7 = 168;
var w_7 = 168;
var X_7 = 15;
var x_7 = 15;
var y_7 = 200;
var Y_7 = 200;
var Z_7 = 184;
var z_7 = 184;
var MINUS_7 = 223;
var AND_7 = 1;
var ATRATE_7 = 16;
var SPACE_7 = 255;
var CHECK_7 = 0;
var UNCHECK_7 = 128;
var selectedlanguageindex =1;
function showCharHindi(arg)
{
	switch (arg)
	{
		case 1://///AAAAAAAA
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/pomegranate.jpg';//pomegranate=Anar
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/ginger.jpg';//ginger=Awrk
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/egg.gif';//egg=Anda
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/pineapple.gif';//pineapple=Ananas
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/arrow.gif';//arrow=Aro
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Anar';
		document.getElementById('foto1lb2').innerHTML = 'Awrq';
		document.getElementById('foto1lb3').innerHTML = 'Anda';
		document.getElementById('foto1lb4').innerHTML = 'Ananas';
		document.getElementById('foto1lb5').innerHTML = 'Aro';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 2:///////aaaaaaaa
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/potato.jpg';//potato=alu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/mango.jpg';//mango=am
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/eye.gif';//eye=aK	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/icecream.gif';//icecream=aiskrim
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'alu';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = 'am';
		document.getElementById('foto1lb4').innerHTML = 'aQ';
		document.getElementById('foto1lb5').innerHTML = 'aisqrim';	
		break;
		case 3://///////iiiiiiiii
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/tamarind.jpg';//tamarind=imli
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/brick.jpg';//brick=iit
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/sugarcane.jpg';//sugarcane=iiK
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/locomotive.jpg';//locomotive=injn
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'imli';
		document.getElementById('foto1lb2').innerHTML = 'it';
		document.getElementById('foto1lb3').innerHTML = 'iQ';
		document.getElementById('foto1lb4').innerHTML = 'injn';
		document.getElementById('foto1lb5').innerHTML = '';		
		break;
		case 4:////////uuuuuuuu
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/owl.jpg';//owl=ullu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/camel1.jpg';//camel1=uut1
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/camel2.gif';//camel2=uut2
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'ullu';
		document.getElementById('foto1lb2').innerHTML = 'ut';
		document.getElementById('foto1lb3').innerHTML = 'ut';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		break;
		case 5://///eeeeeeeee
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/specs.gif';//specs=enq
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'enAq';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 6://///ooooooo
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/okhla.jpg';//okhla=oKla
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'oQla';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';		
		break;
		case 7: //qqqqq
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/ear.gif';//ear=qan
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/qar.gif';//qar
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/qeq.gif';//qeq		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/banana.gif';//banana=qela		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/qp.gif';//qp		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/dog.gif';//dog=quxxa
		document.getElementById('foto1lbl').innerHTML = 'qan';
		document.getElementById('foto1lb2').innerHTML = 'qar';
		document.getElementById('foto1lb3').innerHTML = 'qeq';
		document.getElementById('foto1lb4').innerHTML = 'qela';
		document.getElementById('foto1lb5').innerHTML = 'qp';	
		document.getElementById('foto1lb6').innerHTML = 'quxxa';	
		break;		
		case 8:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/hare.jpg';//hare=QrgoS
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/player.gif';//player=QilaRi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'QrgoS';
		document.getElementById('foto1lb2').innerHTML = 'QilaRi';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 9:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/baloon.gif';//baloon=gubbara
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/cauliflower.gif';//cauliflower=goBi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/globe.gif';//glob		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/van.gif';//van=gaRi		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/cow.gif';//cow=gay	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/gift.gif';//gift
		document.getElementById('foto1lbl').innerHTML = 'gubbara';
		document.getElementById('foto1lb2').innerHTML = 'goBi';
		document.getElementById('foto1lb3').innerHTML = 'glob';
		document.getElementById('foto1lb4').innerHTML = 'gaRi';
		document.getElementById('foto1lb5').innerHTML = 'gay';
		document.getElementById('foto1lb6').innerHTML = 'gift';
		break;
		case 10:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/house.jpg';//house=Gr
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/clock.gif';//clock=GRi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/horse.gif';//horse=GoRa		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/bottlegourd.jpg';//bottlegourd=Giya		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/bell.gif';//bell=Gnti		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/nest.jpg';//nest=Gosla
		document.getElementById('foto1lbl').innerHTML = 'Gr';
		document.getElementById('foto1lb2').innerHTML = 'GRi';
		document.getElementById('foto1lb3').innerHTML = 'GoRa';
		document.getElementById('foto1lb4').innerHTML = 'Giya';
		document.getElementById('foto1lb5').innerHTML = 'Gnti';		
		document.getElementById('foto1lb6').innerHTML = 'Gosla';		
		break;
		case 11:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/cherry.gif';//cherry
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/sleeper.jpg';//sleeper=cppl
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/key.gif';//key=cabi	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/sparrow.gif';//sparrow=ciRiya	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/spoon.gif';//spoon=cmmc	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';//
		document.getElementById('foto1lbl').innerHTML = 'ceri';
		document.getElementById('foto1lb2').innerHTML = 'cppl';
		document.getElementById('foto1lb3').innerHTML = 'cabi';
		document.getElementById('foto1lb4').innerHTML = 'ciRiya';
		document.getElementById('foto1lb5').innerHTML = 'cmmc';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 12:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/umbrela.gif';//umbrela=Cxri
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/bananapeel.jpg';//bananapeel=Cilqa
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/basket.jpg';//basket=CbRi		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/lizard.jpg';//lizard=CipAqli
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Cxri';
		document.getElementById('foto1lb2').innerHTML = 'Cilqa';
		document.getElementById('foto1lb3').innerHTML = 'CbRi';
		document.getElementById('foto1lb4').innerHTML = 'CipAqli';
		document.getElementById('foto1lb5').innerHTML = '';		
		document.getElementById('foto1lb6').innerHTML = '';	
		break;      
		case 13:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/jug.gif';//jug=jg
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/jacket.gif';//jacket=jAqet
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/jeep.gif';//jeep=jiip		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/jeans.gif';//jeans=jiins		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/giraffe.gif';//jiraf		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/spidernet.gif';//jal
		document.getElementById('foto1lbl').innerHTML = 'jg';
		document.getElementById('foto1lb2').innerHTML = 'jAqet';
		document.getElementById('foto1lb3').innerHTML = 'jip';
		document.getElementById('foto1lb4').innerHTML = 'jins';
		document.getElementById('foto1lb5').innerHTML = 'jiraf';
		document.getElementById('foto1lb6').innerHTML = 'jal';
		break;	
		case 14:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Jula.jpg';//Jula
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/waterfall.jpg';//Jrna
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/flag.jpg';//Jnda	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/hut.jpg';//JopRi	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Jula';
		document.getElementById('foto1lb2').innerHTML = 'Jrna';
		document.getElementById('foto1lb3').innerHTML = 'Jnda';
		document.getElementById('foto1lb4').innerHTML = 'JopRi';
		document.getElementById('foto1lb5').innerHTML = '';	
		document.getElementById('foto1lb6').innerHTML = '';	
		break;		
		case 15:////tttttttt
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/tomato.jpg';//tmatr		
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/tub.gif';//tb
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/torch.gif';//torc
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/tofi.gif';//tofi	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/cap.gif';//topi	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/tv.gif';//tivi
		document.getElementById('foto1lbl').innerHTML = 'tmatr';
		document.getElementById('foto1lb2').innerHTML = 'tb';
		document.getElementById('foto1lb3').innerHTML = 'torc';
		document.getElementById('foto1lb4').innerHTML = 'tofi';
		document.getElementById('foto1lb5').innerHTML = 'topi';
		document.getElementById('foto1lb6').innerHTML = 'tivi';
		break;	
		case 16:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/blacksmith.jpg';//TTera
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/cart.gif';//thela
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'TTera';
		document.getElementById('foto1lb2').innerHTML = 'Tela';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';				
		document.getElementById('foto1lb6').innerHTML = '';				
		break;		
		case 17:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/dumble.gif';//dmbl
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/desk.gif';//desq
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/dynasore.gif';//daynasor		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/dancer.gif';//dancer=dansr		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/drum.gif';//drum=drm		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/39.gif';
		document.getElementById('foto1lbl').innerHTML = 'dmbl';
		document.getElementById('foto1lb2').innerHTML = 'desq';
		document.getElementById('foto1lb3').innerHTML = 'daynasor';
		document.getElementById('foto1lb4').innerHTML = 'dansr';
		document.getElementById('foto1lb5').innerHTML = 'drm';
		break;		
		case 18:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/lid.jpg';//dhakkan
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Dqqn';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';		
		document.getElementById('foto1lb6').innerHTML = '';		
		break;
		case 19:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/ridgegourd.jpg';//xori
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/pillow.gif';//xqiya
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/butterfly.jpg';//xixli	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/lock.gif';//xala	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/watermelon.gif';//xrbuj	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/butterfly1.gif';//xixli
		document.getElementById('foto1lbl').innerHTML = 'xori';
		document.getElementById('foto1lb2').innerHTML = 'xqiya';
		document.getElementById('foto1lb3').innerHTML = 'xixli';
		document.getElementById('foto1lb4').innerHTML = 'xala';
		document.getElementById('foto1lb5').innerHTML = 'xrbuj';
		document.getElementById('foto1lb6').innerHTML = 'xixli';
		break;
		case 20:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/plate.jpg';//Xali
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/thurmus.jpg';//Xrms
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/bag.jpg';//Xela
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Xali';
		document.getElementById('foto1lb2').innerHTML = 'Xrms';
		document.getElementById('foto1lb3').innerHTML = 'Xela';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 21:////wwwwwwwww
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/inkpot.jpg';//wvax
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/wall.jpg';//wivar
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/teeth.gif';//wax		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/gloves.gif';//wsxane		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/telescope.gif';//wurbIn		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'wvax';
		document.getElementById('foto1lb2').innerHTML = 'wivar';
		document.getElementById('foto1lb3').innerHTML = 'wax';
		document.getElementById('foto1lb4').innerHTML = 'wsxane';
		document.getElementById('foto1lb5').innerHTML = 'wurbin';		
		document.getElementById('foto1lb6').innerHTML = '';		
		break;
		case 22:////WWWWWWWWWW
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/bow.jpg';//WnuS
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/coriander.jpg';//qoriandr=Wniya
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/thread.jpg';//Waga		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'WnuS';
		document.getElementById('foto1lb2').innerHTML = 'Wniya';
		document.getElementById('foto1lb3').innerHTML = 'Waga';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';				
		document.getElementById('foto1lb6').innerHTML = '';				
		break;		
		case 23:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/tap.gif';//nl
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/lemon.gif';//nimbu
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/coconut.jpg';//nariyl		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/pear.gif';//naspxi		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/boat.gif';//nav		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/nurse.gif';//nrs
		document.getElementById('foto1lbl').innerHTML = 'nl';
		document.getElementById('foto1lb2').innerHTML = 'nimbu';
		document.getElementById('foto1lb3').innerHTML = 'nariyl';
		document.getElementById('foto1lb4').innerHTML = 'naspxi';
		document.getElementById('foto1lb5').innerHTML = 'nav';
		document.getElementById('foto1lb6').innerHTML = 'nrs';
		break;
		case 24:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/thumb.jpg';//NguTa
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/ring.gif';//Nguthi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/grapes.gif';//Ngur	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'ANguTa';
		document.getElementById('foto1lb2').innerHTML = 'ANguTi';
		document.getElementById('foto1lb3').innerHTML = 'ANgur';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 25:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/onion.jpg';//pyaj		
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/feather.gif';//pNQ
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/foot.gif';//pAr
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/pencil.gif';//pAnsil
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/mint.jpg';//mint=puwina		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/tree.gif';//peR
		document.getElementById('foto1lbl').innerHTML = 'pyaj';
		document.getElementById('foto1lb2').innerHTML = 'pNQ';
		document.getElementById('foto1lb3').innerHTML = 'pAr';
		document.getElementById('foto1lb4').innerHTML = 'pnsil';
		document.getElementById('foto1lb5').innerHTML = 'puwina';
		document.getElementById('foto1lb6').innerHTML = 'peR';
		break;
		case 26:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/fon.gif';//fon
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/folder.gif';//foldr
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/scale.gif';//futta		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/flower.gif';//fuul		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/freeze.gif';//friij		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/shovel.gif';//favRa
		document.getElementById('foto1lbl').innerHTML = 'fon';
		document.getElementById('foto1lb2').innerHTML = 'foldr';
		document.getElementById('foto1lb3').innerHTML = 'futta';
		document.getElementById('foto1lb4').innerHTML = 'ful';
		document.getElementById('foto1lb5').innerHTML = 'frij';
		document.getElementById('foto1lb6').innerHTML = 'favRa';
		break;		
		case 27:
		document[ 'foto1' ].src = 'https://sites.google.com/a/font77.com/font77/bus.gif';//bs
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/brush.gif';//brus
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/burger.gif';//brgr		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/bread.gif';//brAd		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/bottle.gif';//boxl	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/drop.gif';//bunw
		document.getElementById('foto1lbl').innerHTML = 'bs';
		document.getElementById('foto1lb2').innerHTML = 'bruS';
		document.getElementById('foto1lb3').innerHTML = 'brgr';
		document.getElementById('foto1lb4').innerHTML = 'brAd';
		document.getElementById('foto1lb5').innerHTML = 'boxl';
		document.getElementById('foto1lb6').innerHTML = 'bunw';
		break;		
		case 28:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/bear.jpg';//Balu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Balu';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;		
		case 29:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/fish.gif';//mCli
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/candle.gif';//mombxxi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/mobile.gif';//mobail	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/frog.gif';//mendk	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/fist.gif';//mutTi		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/groundnut.gif';//mufli
		document.getElementById('foto1lbl').innerHTML = 'mCli';
		document.getElementById('foto1lb2').innerHTML = 'mombxxi';
		document.getElementById('foto1lb3').innerHTML = 'mobail';
		document.getElementById('foto1lb4').innerHTML = 'mendk';
		document.getElementById('foto1lb5').innerHTML = 'mutTi';
		document.getElementById('foto1lb6').innerHTML = 'mufli';
		break;
		case 30:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/yoga.jpg';//yoga
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/yoyo.gif';//yoyo
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'yoga';
		document.getElementById('foto1lb2').innerHTML = 'yoyo';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 31:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/razor.jpg';//rejr
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/rocket.gif';//roqet
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/rubber.gif';//rbR		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/robot.gif';//robot
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'rejr';
		document.getElementById('foto1lb2').innerHTML = 'roqet';
		document.getElementById('foto1lb3').innerHTML = 'rbR';
		document.getElementById('foto1lb4').innerHTML = 'robot';
		document.getElementById('foto1lb5').innerHTML = '';		
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/razor.jpg';//rejr
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/rocket.gif';//roqet
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/rubber.gif';//rbr		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/robot.gif';//robot		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'rejr';
		document.getElementById('foto1lb2').innerHTML = 'roqet';
		document.getElementById('foto1lb3').innerHTML = 'rbR';
		document.getElementById('foto1lb4').innerHTML = 'robot';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';		
		break;
		case 33:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/top.jpg';//lttu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/lighthouse.gif';//laithaus
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/lamp.gif';//lAmp	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/envelope.gif';//lifafa		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/garlic.gif';//lssun		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/lantern.gif';//lalten
		document.getElementById('foto1lbl').innerHTML = 'lttu';
		document.getElementById('foto1lb2').innerHTML = 'laithaus';
		document.getElementById('foto1lb3').innerHTML = 'lAmp';
		document.getElementById('foto1lb4').innerHTML = 'lifafa';
		document.getElementById('foto1lb5').innerHTML = 'lssun';
		document.getElementById('foto1lb6').innerHTML = 'lalten';
		break;
		case 34:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/top.jpg';//lttu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/lighthouse.gif';//laithaus
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/lamp.gif';//lemp	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/envelope.gif';//lifafa		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/garlic.gif';//lssun		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/lantern.gif';//lalten
		document.getElementById('foto1lbl').innerHTML = 'lttu';
		document.getElementById('foto1lb2').innerHTML = 'laithaus';
		document.getElementById('foto1lb3').innerHTML = 'lAmp';
		document.getElementById('foto1lb4').innerHTML = 'lifafa';
		document.getElementById('foto1lb5').innerHTML = 'lssun';
		document.getElementById('foto1lb6').innerHTML = 'lalten';
		break;
		case 35:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/van.gif';//vAn
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/washbasin.gif';//vasbesin
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/washingmachine.gif';//vasingmsin	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/waiter.gif';//vetr	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'vAn';
		document.getElementById('foto1lb2').innerHTML = 'vasbesin';
		document.getElementById('foto1lb3').innerHTML = 'vasingmsin';
		document.getElementById('foto1lb4').innerHTML = 'vetr';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 36:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/cycle.gif';//saiqil
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/sandwich.gif';//sendvic
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/sun.gif';//surAj		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/pig.gif';//suAr		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/whistle.gif';//siti		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/ladder.gif';//siRi
		document.getElementById('foto1lbl').innerHTML = 'saiqil';
		document.getElementById('foto1lb2').innerHTML = 'sendvic';
		document.getElementById('foto1lb3').innerHTML = 'surAj';
		document.getElementById('foto1lb4').innerHTML = 'suAr';
		document.getElementById('foto1lb5').innerHTML = 'siti';
		document.getElementById('foto1lb6').innerHTML = 'siRi';
		break;
		case 37:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/lion.gif';//Ser
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/sandwich.gif';//sndvic
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/turnip.jpg';//Slgm		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';//		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';//		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';//
		document.getElementById('foto1lbl').innerHTML = 'Ser';
		document.getElementById('foto1lb2').innerHTML = 'sendvic';
		document.getElementById('foto1lb3').innerHTML = 'Slgm';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;      
		case 38:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/elephant.gif';//haXi
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/helicopter.gif';//heliqoptr
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/hanger.gif';//hengr		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/horn.gif';//horn		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/lips.gif';//hoT		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/airbus.gif';//hvaijhaj
		document.getElementById('foto1lbl').innerHTML = 'haXi';
		document.getElementById('foto1lb2').innerHTML = 'heliqoptr';
		document.getElementById('foto1lb3').innerHTML = 'hengr';
		document.getElementById('foto1lb4').innerHTML = 'horn';
		document.getElementById('foto1lb5').innerHTML = 'hoT';		
		document.getElementById('foto1lb6').innerHTML = 'hvaijhaj';		
		break;      
	}
}
function showCharKannada(arg)
{
	switch (arg)
	{
		case 1://AAAAAA
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/.jpg';//
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/.jpg';//ginger
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/egg.gif';//egg
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/pineapple.gif';//pineapple		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/arrow.gif';//arrow
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 2://aaaaaa
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/potato.jpg';//potato
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/mango.jpg';//mango	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/aK.gif';//eye	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/icecream.gif';//icecream	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 3:////iiiiii
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/tamarind.jpg';//imli
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/brick.jpg';//iit
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/sugarcane.jpg';//iiK
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/engine.jpg';//injn
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 4://////uuuuuuuuuu
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/owl.jpg';//ullu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/camel1.jpg';//uut
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/camel2.gif';//uut	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 5://///////eeeeeeeeee/
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/ladder.gif';//eni=ladder
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 6://///oooooooo
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/camel.gif';//onte=camel
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 7://////qqqqqqq
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/key.gif';//qan
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/qar.gif';//qar
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/qeq.gif';//qeq		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/corn.jpg';//qoriandr=Kottambari		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/cup.gif';//qp		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/barber.jpg';//quxxa
		document.getElementById('foto1lbl').innerHTML = 'qiliqai'; 
		document.getElementById('foto1lb2').innerHTML = 'qar'; 
		document.getElementById('foto1lb3').innerHTML = 'qeq'; 
		document.getElementById('foto1lb4').innerHTML = 'qalu'; 
		document.getElementById('foto1lb5').innerHTML = 'qp';
		document.getElementById('foto1lb6').innerHTML = 'qsoriqa'; 
		break;		
		case 8://////QQQQQQQ
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/QrgoS.jpg';//QrgoS
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/QilaRi.gif';//QilaRi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 9:////////gggggggg
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/throat.jpg';//gubbara
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/goBi.gif';//goBi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/glob.gif';//glob		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/gaRi.gif';//gaRi		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/gay.gif';//gay	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/gift.gif';//gift		
		document.getElementById('foto1lbl').innerHTML = 'gntlu'; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 10://////GGGGGGG
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Gr.jpg';//Gr
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/GRi.gif';//GRi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/GoRa.gif';//GoRa		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/Giya.jpg';//Giya		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/Gnti.gif';//Gnti		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/Gosla.jpg';//Gosla		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 11:///////cccccccc
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/ceri.gif';//cherry
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/cppl.jpg';//sleeper
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/cabi.gif';//key		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/ciRiya.gif';//sparrow		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/cmmc.gif';//spoon		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';//
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 12://///////CCCCCC
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Cxri.gif';//Cxri
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/Cilqa.jpg';//Cilqa
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/CbRi.jpg';//CbRi		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/CipAqli.jpg';//CipAqli
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;      
		case 13:////////jjjj
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/jug.gif';//jg
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/jacket.gif';//jqet
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/jeep.gif';//jiip		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/jeans.gif';//jiins		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/giraffe.gif';//jiraf		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/judo.gif';//jal	
		document.getElementById('foto1lbl').innerHTML = 'jg'; 
		document.getElementById('foto1lb2').innerHTML = 'jAqet'; 
		document.getElementById('foto1lb3').innerHTML = 'jiip'; 
		document.getElementById('foto1lb4').innerHTML = 'jiins'; 
		document.getElementById('foto1lb5').innerHTML = 'jiraf';
		document.getElementById('foto1lb6').innerHTML = 'judo'; 
		break;	
		case 14://///JJJJJ
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Jula.jpg';//Jula
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/Jrna.jpg';//Jrna
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/Jnda.jpg';//Jnda	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/JopRi.jpg';//JopRi	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';	
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 15://///tttttttttt
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/tshirt.jpg';//tshirt		
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/tub.gif';//tb
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/torch.gif';//torc
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/ticket.jpg';//tofi	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/tyre.jpg';//topi	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/tv.gif';//tivi				
		document.getElementById('foto1lbl').innerHTML = 'tiSrt'; 
		document.getElementById('foto1lb2').innerHTML = 'tb'; 
		document.getElementById('foto1lb3').innerHTML = 'torc'; 
		document.getElementById('foto1lb4').innerHTML = 'tiqt'; 
		document.getElementById('foto1lb5').innerHTML = 'tayr';
		document.getElementById('foto1lb6').innerHTML = 'tivi'; 
		break;	
		case 16://///TTTTTTT
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/TTera.jpg';//thathera
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/Tela.gif';//thela
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';				
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 17://///dddddddd
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/dumble.gif';//dmbl
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/desk.gif';//desq
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/dynasore.gif';//daynasor		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/dancer.gif';//dancer=dansr		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/drum.gif';//drum=drm		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/dosa.jpg';	
		document.getElementById('foto1lbl').innerHTML = 'dmbl'; 
		document.getElementById('foto1lb2').innerHTML = 'desq'; 
		document.getElementById('foto1lb3').innerHTML = 'daynasor'; 
		document.getElementById('foto1lb4').innerHTML = 'dansr'; 
		document.getElementById('foto1lb5').innerHTML = 'drm';
		document.getElementById('foto1lb6').innerHTML = 'dosa'; 
		break;		
		case 18://////DDDDDDD
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Dkkn.jpg';//dhakkan
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 19://////xxxxxxxx
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/xori.jpg';//xori
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/xqiya.gif';//xqiya
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/xixli.jpg';//xixli	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/xala.gif';//xala	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/xrbuj.gif';//xrbuj	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/xixli.gif';//xixli		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 20:////XXXXXXX
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Xali.jpg';//Xali
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/Xrms.jpg';//Xrms
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/Xela.jpg';//Xela
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 21:///////wwwwwwwww
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/pomegranate.jpg';//pomegranate=waLimbe
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/wivar.jpg';//wivar
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/wax.gif';//wax		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/wsxane.gif';//wsxane		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/wurbiin.gif';//wurbiin		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = 'waLimbe'; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 22://///////WWWWWWWWW
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/WnuS.jpg';//WnuS
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/Wniya.jpg';//Wniya
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/Waga.jpg';//Waga		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';				
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 23:////////////nnnnnnnnn
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/nl.gif';//nl
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/nimbu.gif';//nimbu
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/nariyl.jpg';//nariyl		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/naspxi.gif';//naspxi		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/nailpolish.jpg';//nav		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/nrs.gif';//nrs			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = 'nelpolis';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 24:///////////NNNNNNNNNNN
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/NguTa.jpg';//NguTa
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/NguTi.gif';//Nguthi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/Ngur.gif';//Ngur	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 25:////////pppppppp
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/pencil.gif';//pyaj		
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/pipe.jpg';//pNQ
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/plate.jpg';//pAr
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/police.gif';//pAnsil
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/pant.gif';//pAnt		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/pizza2.gif';//peR			
		document.getElementById('foto1lbl').innerHTML = 'pAnsil'; 
		document.getElementById('foto1lb2').innerHTML = 'paip'; 
		document.getElementById('foto1lb3').innerHTML = 'plet'; 
		document.getElementById('foto1lb4').innerHTML = 'pulis'; 
		document.getElementById('foto1lb5').innerHTML = 'pAnt';
		document.getElementById('foto1lb6').innerHTML = 'pijja'; 
		break;
		case 26://///fffffffff
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/fon.gif';//fon
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/foldr.gif';//foldr
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/futta.gif';//futta		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/fuul.gif';//fuul		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/friij.gif';//friij		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/favRa.gif';//favRa	
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 27:///////bbbbbbbbb
		document[ 'foto1' ].src = 'https://sites.google.com/a/font77.com/font77/bus.gif';//bs
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/brush.gif';//brus
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/burger.gif';//brgr		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/bread.gif';//brAd		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/bottle.gif';//boxl	
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/shirtbutton.jpg';//bunw		
		document.getElementById('foto1lbl').innerHTML = 'bs'; 
		document.getElementById('foto1lb2').innerHTML = 'brus'; 
		document.getElementById('foto1lb3').innerHTML = 'brgr'; 
		document.getElementById('foto1lb4').innerHTML = 'brAd'; 
		document.getElementById('foto1lb5').innerHTML = 'botl';
		document.getElementById('foto1lb6').innerHTML = 'btn'; 
		break;		
		case 28:////////BBBBBBBBB
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/Balu.jpg';//Balu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 29://////mmmmmmm
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/mCli.gif';//mCli
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/mombxxi.gif';//mombxxi
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/mobail.gif';//mobail	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/mendk.gif';//mendk	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/mutTi.gif';//mutTi		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/mufli.gif';//mufli		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 30://///yyyyyyyyy
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/yoga.jpg';//yoga
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/yoyo.gif';//yoyo
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 31:///////rrrrrrrrrr
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/rejr.jpg';//rejr
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/roqet.gif';//roqet
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/rbR.gif';//rbR		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/robot.gif';//robot
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 32:////RRRRRR
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/rejr.jpg';//rejr
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/roqet.gif';//roqet
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/rbR.gif';//rbr		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/robot.gif';//robot		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 33:///////lllllll
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/lttu.jpg';//lttu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/laithaus.gif';//laithaus
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/lemp.gif';//lemp	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/lion.gif';//lifafa		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/lssun.gif';//lssun		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/lalten.gif';//lalten			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = 'layn'; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 34:///////LLLLLLLL
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/lttu.jpg';//lttu
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/laithaus.gif';//laithaus
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/lemp.gif';//lemp	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/lifafa.gif';//lifafa		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/lssun.gif';//lssun		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/lalten.gif';//lalten	
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 35:///////vvvvvvvvv
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/vAn.gif';//vAn
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/washbasin.gif';//vasbesin
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/washingmachine.gif';//vasingmsin	
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/vetr.gif';//vetr	
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/airbus.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = 'vAn'; 
		document.getElementById('foto1lb2').innerHTML = 'vasbesin'; 
		document.getElementById('foto1lb3').innerHTML = 'vasingmsin'; 
		document.getElementById('foto1lb4').innerHTML = 'vetr'; 
		document.getElementById('foto1lb5').innerHTML = 'vimana';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 36://////sssssss
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/surya.gif';//saiqil
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/sndvic.gif';//sndvic
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/ginger.gif';//sunTi		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/groundnut.gif';//		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/siiti.gif';//siiti		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/siRi.gif';//siRi
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = 'sunTi'; 
		document.getElementById('foto1lb4').innerHTML = 'seNga'; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 37://////SSSSSSS
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/saiqil.gif';//saiqil
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/sndvic.gif';//sndvic
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/surj.gif';//surj		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/suAr.gif';//suAr		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/siiti.gif';//siiti		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/siRi.gif';//siRi
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;      
		case 38://////hhhhhhhh
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/hani.gif';//hani=drop
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/handi.gif';//handi=pig
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/heNgr.gif';//heNgr		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/horn.gif';//horn		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/hoT.gif';//hoT		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/hare.jpg';//hvaijhaj		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = 'mola'; 
		break;      
	}
}
function showCharOriya(arg)
{
	switch (arg)
	{
		case 1:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.gif';		
		document['foto4'].src = '4.gif';		
		document['foto5'].src = '173.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 2:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.gif';		
		document['foto5'].src = '147.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 3:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 4:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 5:
		document['foto1'].src = '38.gif';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 6:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 7:
		document['foto1'].src = '75.gif';
		document['foto2'].src = '76.gif';
		document['foto3'].src = '79.gif';		
		document['foto4'].src = '80.gif';		
		document['foto5'].src = '89.gif';		
		document['foto6'].src = '93.gif';		
		break;		
		case 8:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 9:
		document['foto1'].src = '52.gif';
		document['foto2'].src = '53.gif';
		document['foto3'].src = '54.gif';		
		document['foto4'].src = '44.gif';		
		document['foto5'].src = '47.gif';		
		document['foto6'].src = '56.gif';		
		break;
		case 10:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.gif';
		document['foto3'].src = '57.gif';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.gif';		
		document['foto6'].src = '234.jpg';			
		break;
		case 11:
		document['foto1'].src = '22.gif';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.gif';		
		document['foto4'].src = '25.gif';		
		document['foto5'].src = '23.gif';		
		document['foto6'].src = '0.GIF';			
		break;
		case 12:
		document['foto1'].src = '24.gif';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;      
		case 13:
		document['foto1'].src = '67.gif';
		document['foto2'].src = '69.gif';
		document['foto3'].src = '70.gif';		
		document['foto4'].src = '71.gif';		
		document['foto5'].src = '74.gif';		
		document['foto6'].src = '72.gif';	
		break;	
		case 14:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;		
		case 15:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.gif';
		document['foto2'].src = '169.gif';
		document['foto3'].src = '171.gif';		
		document['foto4'].src = '164.gif';		
		document['foto5'].src = '170.gif';				
		break;	
		case 16:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 17:
		document['foto1'].src = '29.gif';
		document['foto2'].src = '30.gif';
		document['foto3'].src = '31.gif';		
		document['foto4'].src = '32.gif';		
		document['foto5'].src = '34.gif';		
		document['foto6'].src = '39.gif';	
		break;		
		case 18:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 19:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.gif';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.gif';		
		document['foto5'].src = '160.gif';		
		document['foto6'].src = '163.gif';		
		break;
		case 20:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 21:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.gif';		
		document['foto4'].src = '40.gif';		
		document['foto5'].src = '167.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 22:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 23:
		document['foto1'].src = '184.gif';
		document['foto2'].src = '113.gif';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.gif';		
		document['foto5'].src = '110.gif';		
		document['foto6'].src = '115.gif';			
		break;
		case 24:
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.gif';
		document['foto3'].src = '114.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 25:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.gif';
		document['foto3'].src = '121.gif';
		document['foto4'].src = '120.gif';
		document['foto5'].src = '119.gif';		
		document['foto6'].src = '118.gif';			
		break;
		case 26:
		document['foto1'].src = '49.gif';
		document['foto2'].src = '48.gif';
		document['foto3'].src = '43.gif';		
		document['foto4'].src = '42.gif';		
		document['foto5'].src = '41.gif';		
		document['foto6'].src = '37.gif';		
		break;		
		case 27:
		document[ 'foto1' ].src = '12.gif';
		document['foto2'].src = '13.gif';
		document['foto3'].src = '14.gif';		
		document['foto4'].src = '15.gif';		
		document['foto5'].src = '16.gif';		
		document['foto6'].src = '20.gif';			
		break;		
		case 28:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;		
		case 29:
		document['foto1'].src = '99.gif';
		document['foto2'].src = '103.gif';
		document['foto3'].src = '104.gif';		
		document['foto4'].src = '106.gif';		
		document['foto5'].src = '109.gif';		
		document['foto6'].src = '101.gif';			
		break;
		case 30:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 31:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 32:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 33:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';			
		break;
		case 34:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';
		break;
		case 35:
		document['foto1'].src = '44.gif';
		document['foto2'].src = '151.gif';
		document['foto3'].src = '175.gif';		
		document['foto4'].src = '176.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 36:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;
		case 37:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;      
		case 38:
		document['foto1'].src = '59.gif';
		document['foto2'].src = '62.gif';
		document['foto3'].src = '63.gif';		
		document['foto4'].src = '64.gif';		
		document['foto5'].src = '65.gif';		
		document['foto6'].src = '66.gif';		
		break;      
	}
}
function showCharMalayalam(arg)
{
	switch (arg)
	{
		case 1:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.gif';		
		document['foto4'].src = '4.gif';		
		document['foto5'].src = '173.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 2:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.gif';		
		document['foto5'].src = '147.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 3:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 4:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 5:
		document['foto1'].src = '38.gif';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 6:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 7:
		document['foto1'].src = '75.gif';
		document['foto2'].src = '76.gif';
		document['foto3'].src = '79.gif';		
		document['foto4'].src = '80.gif';		
		document['foto5'].src = '89.gif';		
		document['foto6'].src = '93.gif';		
		break;		
		case 8:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 9:
		document['foto1'].src = '52.gif';
		document['foto2'].src = '53.gif';
		document['foto3'].src = '54.gif';		
		document['foto4'].src = '44.gif';		
		document['foto5'].src = '47.gif';		
		document['foto6'].src = '56.gif';		
		break;
		case 10:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.gif';
		document['foto3'].src = '57.gif';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.gif';		
		document['foto6'].src = '234.jpg';			
		break;
		case 11:
		document['foto1'].src = '22.gif';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.gif';		
		document['foto4'].src = '25.gif';		
		document['foto5'].src = '23.gif';		
		document['foto6'].src = '0.GIF';			
		break;
		case 12:
		document['foto1'].src = '24.gif';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;      
		case 13:
		document['foto1'].src = '67.gif';
		document['foto2'].src = '69.gif';
		document['foto3'].src = '70.gif';		
		document['foto4'].src = '71.gif';		
		document['foto5'].src = '74.gif';		
		document['foto6'].src = '72.gif';	
		break;	
		case 14:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;		
		case 15:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.gif';
		document['foto2'].src = '169.gif';
		document['foto3'].src = '171.gif';		
		document['foto4'].src = '164.gif';		
		document['foto5'].src = '170.gif';				
		break;	
		case 16:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 17:
		document['foto1'].src = '29.gif';
		document['foto2'].src = '30.gif';
		document['foto3'].src = '31.gif';		
		document['foto4'].src = '32.gif';		
		document['foto5'].src = '34.gif';		
		document['foto6'].src = '39.gif';	
		break;		
		case 18:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 19:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.gif';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.gif';		
		document['foto5'].src = '160.gif';		
		document['foto6'].src = '163.gif';		
		break;
		case 20:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 21:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.gif';		
		document['foto4'].src = '40.gif';		
		document['foto5'].src = '167.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 22:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 23:
		document['foto1'].src = '184.gif';
		document['foto2'].src = '113.gif';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.gif';		
		document['foto5'].src = '110.gif';		
		document['foto6'].src = '115.gif';			
		break;
		case 24:
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.gif';
		document['foto3'].src = '114.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 25:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.gif';
		document['foto3'].src = '121.gif';
		document['foto4'].src = '120.gif';
		document['foto5'].src = '119.gif';		
		document['foto6'].src = '118.gif';			
		break;
		case 26:
		document['foto1'].src = '49.gif';
		document['foto2'].src = '48.gif';
		document['foto3'].src = '43.gif';		
		document['foto4'].src = '42.gif';		
		document['foto5'].src = '41.gif';		
		document['foto6'].src = '37.gif';		
		break;		
		case 27:
		document[ 'foto1' ].src = '12.gif';
		document['foto2'].src = '13.gif';
		document['foto3'].src = '14.gif';		
		document['foto4'].src = '15.gif';		
		document['foto5'].src = '16.gif';		
		document['foto6'].src = '20.gif';			
		break;		
		case 28:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;		
		case 29:
		document['foto1'].src = '99.gif';
		document['foto2'].src = '103.gif';
		document['foto3'].src = '104.gif';		
		document['foto4'].src = '106.gif';		
		document['foto5'].src = '109.gif';		
		document['foto6'].src = '101.gif';			
		break;
		case 30:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 31:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 32:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 33:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';			
		break;
		case 34:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';
		break;
		case 35:
		document['foto1'].src = '44.gif';
		document['foto2'].src = '151.gif';
		document['foto3'].src = '175.gif';		
		document['foto4'].src = '176.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 36:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;
		case 37:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;      
		case 38:
		document['foto1'].src = '59.gif';
		document['foto2'].src = '62.gif';
		document['foto3'].src = '63.gif';		
		document['foto4'].src = '64.gif';		
		document['foto5'].src = '65.gif';		
		document['foto6'].src = '66.gif';		
		break;      
	}
}
function showCharPunjabi(arg)
{
	switch (arg)
	{
		case 1:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.gif';		
		document['foto4'].src = '4.gif';		
		document['foto5'].src = '173.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 2:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.gif';		
		document['foto5'].src = '147.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 3:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 4:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 5:
		document['foto1'].src = '38.gif';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 6:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 7:
		document['foto1'].src = '75.gif';
		document['foto2'].src = '76.gif';
		document['foto3'].src = '79.gif';		
		document['foto4'].src = '80.gif';		
		document['foto5'].src = '89.gif';		
		document['foto6'].src = '93.gif';		
		break;		
		case 8:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 9:
		document['foto1'].src = '52.gif';
		document['foto2'].src = '53.gif';
		document['foto3'].src = '54.gif';		
		document['foto4'].src = '44.gif';		
		document['foto5'].src = '47.gif';		
		document['foto6'].src = '56.gif';		
		break;
		case 10:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.gif';
		document['foto3'].src = '57.gif';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.gif';		
		document['foto6'].src = '234.jpg';			
		break;
		case 11:
		document['foto1'].src = '22.gif';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.gif';		
		document['foto4'].src = '25.gif';		
		document['foto5'].src = '23.gif';		
		document['foto6'].src = '0.GIF';			
		break;
		case 12:
		document['foto1'].src = '24.gif';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;      
		case 13:
		document['foto1'].src = '67.gif';
		document['foto2'].src = '69.gif';
		document['foto3'].src = '70.gif';		
		document['foto4'].src = '71.gif';		
		document['foto5'].src = '74.gif';		
		document['foto6'].src = '72.gif';	
		break;	
		case 14:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;		
		case 15:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.gif';
		document['foto2'].src = '169.gif';
		document['foto3'].src = '171.gif';		
		document['foto4'].src = '164.gif';		
		document['foto5'].src = '170.gif';				
		break;	
		case 16:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 17:
		document['foto1'].src = '29.gif';
		document['foto2'].src = '30.gif';
		document['foto3'].src = '31.gif';		
		document['foto4'].src = '32.gif';		
		document['foto5'].src = '34.gif';		
		document['foto6'].src = '39.gif';	
		break;		
		case 18:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 19:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.gif';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.gif';		
		document['foto5'].src = '160.gif';		
		document['foto6'].src = '163.gif';		
		break;
		case 20:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 21:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.gif';		
		document['foto4'].src = '40.gif';		
		document['foto5'].src = '167.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 22:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 23:
		document['foto1'].src = '184.gif';
		document['foto2'].src = '113.gif';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.gif';		
		document['foto5'].src = '110.gif';		
		document['foto6'].src = '115.gif';			
		break;
		case 24:
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.gif';
		document['foto3'].src = '114.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 25:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.gif';
		document['foto3'].src = '121.gif';
		document['foto4'].src = '120.gif';
		document['foto5'].src = '119.gif';		
		document['foto6'].src = '118.gif';			
		break;
		case 26:
		document['foto1'].src = '49.gif';
		document['foto2'].src = '48.gif';
		document['foto3'].src = '43.gif';		
		document['foto4'].src = '42.gif';		
		document['foto5'].src = '41.gif';		
		document['foto6'].src = '37.gif';		
		break;		
		case 27:
		document[ 'foto1' ].src = '12.gif';
		document['foto2'].src = '13.gif';
		document['foto3'].src = '14.gif';		
		document['foto4'].src = '15.gif';		
		document['foto5'].src = '16.gif';		
		document['foto6'].src = '20.gif';			
		break;		
		case 28:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;		
		case 29:
		document['foto1'].src = '99.gif';
		document['foto2'].src = '103.gif';
		document['foto3'].src = '104.gif';		
		document['foto4'].src = '106.gif';		
		document['foto5'].src = '109.gif';		
		document['foto6'].src = '101.gif';			
		break;
		case 30:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 31:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 32:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 33:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';			
		break;
		case 34:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';
		break;
		case 35:
		document['foto1'].src = '44.gif';
		document['foto2'].src = '151.gif';
		document['foto3'].src = '175.gif';		
		document['foto4'].src = '176.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 36:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;
		case 37:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;      
		case 38:
		document['foto1'].src = '59.gif';
		document['foto2'].src = '62.gif';
		document['foto3'].src = '63.gif';		
		document['foto4'].src = '64.gif';		
		document['foto5'].src = '65.gif';		
		document['foto6'].src = '66.gif';		
		break;      
	}
}
function completeCharHindi(arg)
{
	switch (arg)
	{
		case 255://alert("playChar vith 255");
		case 128: case 0:
		document['foto1'].src = '0.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 156:
		document['foto1'].src = '0.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;			
		case 129:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.gif';		
		document['foto4'].src = '4.gif';		
		document['foto5'].src = '173.gif';		
		document['foto6'].src = '0.GIF';
		ta1.value += "\u0905";
		break;
		case 144:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.gif';		
		document['foto5'].src = '147.gif';		
		document['foto6'].src = '0.GIF';
		break;
		case 192:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 136:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 130:
		document['foto1'].src = '38.gif';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 160:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 10://NN
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.gif';
		document['foto3'].src = '114.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 193: //boks 8
		document['foto1'].src = '75.gif';
		document['foto2'].src = '76.gif';
		document['foto3'].src = '79.gif';		
		document['foto4'].src = '80.gif';		
		document['foto5'].src = '89.gif';		
		document['foto6'].src = '93.gif';
		break;
		case 65:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 164:
		document['foto1'].src = '52.gif';
		document['foto2'].src = '53.gif';
		document['foto3'].src = '54.gif';		
		document['foto4'].src = '44.gif';		
		document['foto5'].src = '47.gif';		
		document['foto6'].src = '56.gif';
		break;
		case 36:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.gif';
		document['foto3'].src = '57.gif';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.gif';		
		document['foto6'].src = '234.jpg';
		break;
		case 18:
		document['foto1'].src = '0.gif';
		document['foto2'].src = '0.gif';
		document['foto3'].src = '0.gif';		
		document['foto4'].src = '0.gif';		
		document['foto5'].src = '0.gif';		
		document['foto6'].src = '0.gif';
		break;			
		case 224:
		document['foto1'].src = '22.gif';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.gif';		
		document['foto4'].src = '25.gif';		
		document['foto5'].src = '23.gif';		
		document['foto6'].src = '0.GIF';
		break;	
		case 96:
		document['foto1'].src = '24.gif';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 176:
		document['foto1'].src = '67.gif';
		document['foto2'].src = '69.gif';
		document['foto3'].src = '70.gif';		
		document['foto4'].src = '71.gif';		
		document['foto5'].src = '74.gif';		
		document['foto6'].src = '72.gif';
		break;	
		case 48:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 132:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.gif';
		document['foto2'].src = '169.gif';
		document['foto3'].src = '171.gif';		
		document['foto4'].src = '164.gif';		
		document['foto5'].src = '170.gif';
		break;		
		case 4:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 152:
		document['foto1'].src = '29.gif';
		document['foto2'].src = '30.gif';
		document['foto3'].src = '31.gif';		
		document['foto4'].src = '32.gif';		
		document['foto5'].src = '34.gif';		
		document['foto6'].src = '39.gif';
		break;
		case 24:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 145:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.gif';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.gif';		
		document['foto5'].src = '160.gif';		
		document['foto6'].src = '163.gif';
		break;
		case 17:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 133:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.gif';		
		document['foto4'].src = '40.gif';		
		document['foto5'].src = '167.gif';		
		document['foto6'].src = '0.GIF';
		break;
		case 5:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 138:
		document['foto1'].src = '184.gif';
		document['foto2'].src = '113.gif';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.gif';		
		document['foto5'].src = '110.gif';		
		document['foto6'].src = '115.gif';
		break;
		case 131:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.gif';
		document['foto3'].src = '121.gif';
		document['foto4'].src = '120.gif';
		document['foto5'].src = '119.gif';		
		document['foto6'].src = '118.gif';
		break;		
		case 135:
		document['foto1'].src = '49.gif';
		document['foto2'].src = '48.gif';
		document['foto3'].src = '43.gif';		
		document['foto4'].src = '42.gif';		
		document['foto5'].src = '41.gif';		
		document['foto6'].src = '37.gif';
		break;		
		case 140:
		document[ 'foto1' ].src = '12.gif';
		document['foto2'].src = '13.gif';
		document['foto3'].src = '14.gif';		
		document['foto4'].src = '15.gif';		
		document['foto5'].src = '16.gif';		
		document['foto6'].src = '20.gif';
		break;		
		case 12:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 161:
		document['foto1'].src = '99.gif';
		document['foto2'].src = '103.gif';
		document['foto3'].src = '104.gif';		
		document['foto4'].src = '106.gif';		
		document['foto5'].src = '109.gif';		
		document['foto6'].src = '101.gif';
		break;
		case 200:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 146:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 162:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';
		break;
		case 168:
		document['foto1'].src = '44.gif';
		document['foto2'].src = '151.gif';
		document['foto3'].src = '175.gif';		
		document['foto4'].src = '176.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 196:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;
		case 137:
		document['foto1'].src = '59.gif';
		document['foto2'].src = '62.gif';
		document['foto3'].src = '63.gif';		
		document['foto4'].src = '64.gif';		
		document['foto5'].src = '65.gif';		
		document['foto6'].src = '66.gif';
		break;
	}
	//previousarg=arg;
}
function showNmbrs(arg)
{
	document['foto1'].src = '0.gif';
	switch (arg)
	{
		case 1: document['foto1'].src = '0.gif';break;
		case 2: document['foto1'].src = 'n1.gif';break;
		case 3: document['foto1'].src = 'n2.gif';break;
		case 4: document['foto1'].src = 'n3.gif';break;
		case 7: document['foto1'].src = 'n4.gif';break;
		case 8: document['foto1'].src = 'n5.gif';break;
		case 9: document['foto1'].src = 'n6.gif';break;
		case 10: document['foto1'].src = 'n7.gif';break;
		case 13: document['foto1'].src = 'n8.gif';break;
		case 14: document['foto1'].src = 'n9.gif';break;
		case 15: document['foto1'].src = 'n10.gif';break;
		case 16: document['foto1'].src = 'n11.gif';break;
		case 19: document['foto1'].src = 'n12.gif';break;
		case 20: document['foto1'].src = 'n13.gif';break;
		case 21: document['foto1'].src = 'n14.gif';break;
		case 22: document['foto1'].src = 'n15.gif';break;
	}
	document['foto2'].src = '0.gif';
	document['foto3'].src = '0.gif';
	document['foto4'].src = '0.gif';
	document['foto5'].src = '0.gif';
	document['foto6'].src = '0.gif';
}
function showCharEnglish(arg)
{
	switch (arg)
	{
		case 1:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/arrow.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/apple.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/umbrela.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'Aro';
		document.getElementById('foto1lb2').innerHTML = 'Appl';
		document.getElementById('foto1lb3').innerHTML = 'Ambrela';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 2:
		document[ 'foto1' ].src = 'https://sites.google.com/a/font77.com/font77/burger.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/bread.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/bottle.gif';		  
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/baloon.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/bell.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/banana.gif';	
		document.getElementById('foto1lbl').innerHTML = 'brgr';
		document.getElementById('foto1lb2').innerHTML = 'brAd';
		document.getElementById('foto1lb3').innerHTML = 'botl';
		document.getElementById('foto1lb4').innerHTML = 'bAlun';
		document.getElementById('foto1lb5').innerHTML = 'bAl';
		document.getElementById('foto1lb6').innerHTML = 'bnana';
		break;		
		case 3:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/chair.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/cherry.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/chisel.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'ceyr';
		document.getElementById('foto1lb2').innerHTML = 'ceri';
		document.getElementById('foto1lb3').innerHTML = 'cijl';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 4:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/drop.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/dog.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/desk.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/duck.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/dice.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/drum.gif';
		document.getElementById('foto1lbl').innerHTML = 'drop';
		document.getElementById('foto1lb2').innerHTML = 'dog';
		document.getElementById('foto1lb3').innerHTML = 'desq';
		document.getElementById('foto1lb4').innerHTML = 'dq';
		document.getElementById('foto1lb5').innerHTML = 'dais';
		document.getElementById('foto1lb6').innerHTML = 'drm';
		break;		
		case 5:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/elephant.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/elevator.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/airbus.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'elifAnt';
		document.getElementById('foto1lb2').innerHTML = 'elivetr';
		document.getElementById('foto1lb3').innerHTML = 'eyrbs';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 6:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/flower.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/fish.gif';		
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/frog.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/folder.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/fork.gif';
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/funnel.gif';
		document.getElementById('foto1lbl').innerHTML = 'flovr';
		document.getElementById('foto1lb2').innerHTML = 'fis';
		document.getElementById('foto1lb3').innerHTML = 'frog';
		document.getElementById('foto1lb4').innerHTML = 'foldr';
		document.getElementById('foto1lb5').innerHTML = 'forq';
		document.getElementById('foto1lb6').innerHTML = 'fnAl';
		break;		
		case 7:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/grapes.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/gloves.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/globe.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/gift.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/violin.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'greps';
		document.getElementById('foto1lb2').innerHTML = 'glovs';
		document.getElementById('foto1lb3').innerHTML = 'glob';
		document.getElementById('foto1lb4').innerHTML = 'gift';
		document.getElementById('foto1lb5').innerHTML = 'gitar';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 8:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/hairs.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/horn.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/hat.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/horse.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/helicopter.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/hanger.gif';
		document.getElementById('foto1lbl').innerHTML = 'heyrs';
		document.getElementById('foto1lb2').innerHTML = 'horn';
		document.getElementById('foto1lb3').innerHTML = 'hAt';
		document.getElementById('foto1lb4').innerHTML = 'hors';
		document.getElementById('foto1lb5').innerHTML = 'heliqoptr';
		document.getElementById('foto1lb6').innerHTML = 'hANgr';
		break;
		case 9:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/inkpot.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/locomotive.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/95.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/75.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/141.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = 'iNq';
		document.getElementById('foto1lb2').innerHTML = 'injn';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 10:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/68.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/74.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/71.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/70.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/69.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/67.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 11:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/103.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/83.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/6.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/88.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 12:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/159.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/149.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/113.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/97.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/65.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/122.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 13:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/108.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/104.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/18.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/100.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/102.gif';		
		//document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/205.jpg';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 14:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/200.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/91.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/115.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/234.jpg';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 15:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/206.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/202.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 16:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/120.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/131.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/156.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/132.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/119.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/111.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 17:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/103.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/83.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/6.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/88.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 18:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/45.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/133.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/5.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/8.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/137.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/43.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 19:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/23.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/25.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/139.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/140.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/107.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/157.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 20:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/26.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/169.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/171.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/178.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/121.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/166.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 21:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 22:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/44.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/176.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/73.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/175.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/160.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/152.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 23:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/44.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/176.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/73.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/175.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/160.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/152.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 24:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/237.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 25:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/177.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/199.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/198.jpg';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 26:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/68.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/74.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/236.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/70.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/69.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/67.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 27:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/146.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/225.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/147.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 28:
		document[ 'foto1' ].src = 'https://sites.google.com/a/font77.com/font77/14.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/15.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/16.gif';		  
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/52.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/58.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/80.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 29:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/229.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/22.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/2.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 30:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/20.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/93.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/30.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/11.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/33.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/34.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 31:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/114.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/40.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/54.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/56.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/38.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/55.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/68.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/74.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/71.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/70.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/69.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/67.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 33:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/103.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/83.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/6.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/88.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 34:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/193.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/5.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/114.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 35:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/26.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/169.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/171.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/178.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/121.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/166.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 36:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
	}
}
function completeCharEnglish(arg)
{
	switch (arg)
	{
		case 129://boks1
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/173.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/231.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/24.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		//alert("hello");
		ta1.value += "A";
		//alert(ta1.value);		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 140:
		document[ 'foto1' ].src = 'https://sites.google.com/a/font77.com/font77/14.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/15.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/16.gif';		  
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/52.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/58.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/80.gif';
		ta1.value += "b";
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 166://boks3
		case 158:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/229.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/22.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/2.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		ta1.value += "c";
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 152://boks4
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/20.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/93.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/30.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/11.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/33.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/34.gif';
		ta1.value += "d";
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 130://boks5 E
		case 134://boks5 e
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/3.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/59.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/66.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 130 == arg ) {ta1.value += "e";}else{ta1.value += "E";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 7:
		case 135://boks6 F
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/42.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/99.gif';		
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/106.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/48.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/78.gif';
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/180.gif';
		if( 135 == arg ) {ta1.value += "f";}else{ta1.value += "F";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 36:
		case 164://boks7 G
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/114.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/40.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/54.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/56.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/38.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/55.gif';
		if( 164 == arg ) {ta1.value += "g";}else{ta1.value += "G";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 137://boks8
		case 141://boks8
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/7.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/64.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/170.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/57.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/62.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/63.gif';
		if( 137 == arg ) {ta1.value += "H";}else{ta1.value += "h";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 192://boks9
		case 253://boks9
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/189.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/187.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/95.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/75.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/141.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 192 == arg ) {ta1.value += "I";}else{ta1.value += "i";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 184://boks10
		case 176://boks10
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/68.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/74.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/71.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/70.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/69.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/67.gif';
		if( 137 == arg ) {ta1.value += "J";}else{ta1.value += "J";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 193://boks11
		case 143://boks11
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/103.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/83.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/6.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/88.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		if( 143 == arg ) {ta1.value += "K";}else{ta1.value += "q";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 174://boks12
		case 162://boks12
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/159.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/149.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/113.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/97.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/65.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/122.gif';
		if( 162 == arg ) {ta1.value += "L";}else{ta1.value += "L";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 33:
		case 161://boks13
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/108.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/205.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/18.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/100.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/102.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/104.gif';
		if( 33 == arg ) {ta1.value += "M";}else{ta1.value += "m";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 157://boks14
		case 138://boks14
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/200.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/91.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/115.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/234.jpg';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 138 == arg ) {ta1.value += "N";}else{ta1.value += "n";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32://boks15
		case 160://boks15
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/206.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/202.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 32 == arg ) {ta1.value += "O";}else{ta1.value += "o";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 131://boks16
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/120.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/131.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/156.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/132.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/119.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/111.gif';
		if( 131 == arg ) {ta1.value += "P";}else{ta1.value += "P";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 65:
		case 193://boks17
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/103.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/83.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/6.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/88.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		if( 65 == arg ) {ta1.value += "Q";}else{ta1.value += "q";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 146://boks18  R
		case 159://boks18 r
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/45.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/133.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/5.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/8.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/137.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/43.gif';
		if( 146 == arg ) {ta1.value += "R";}else{ta1.value += "r";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 68: //S
		case 196://boks19 s
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/23.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/25.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/139.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/140.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/107.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/157.gif';
		if( 68 == arg ) {ta1.value += "S";}else{ta1.value += "s";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 14://T
		case 142://boks20 t
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/26.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/169.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/171.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/178.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/121.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/166.gif';
		if( 14 == arg ) {ta1.value += "T";}else{ta1.value += "t";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 136://boks21 U
		case 188://boks21 u
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 136 == arg ) {ta1.value += "U";}else{ta1.value += "u";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 40:
		case 168://boks22
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/44.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/176.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/73.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/175.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/160.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/152.gif';
		if( 40 == arg ) {ta1.value += "W";}else{ta1.value += "V";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
/*		case 40://boks23
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/44.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/176.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/73.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/175.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/160.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/152.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;*/
		case 15://boks24 x
		case 65://boks24 X
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/237.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.gif';
		if( 15 == arg ) {ta1.value += "x";}else{ta1.value += "X";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 72:
		case 200://boks25
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/177.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/199.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/198.jpg';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 72 == arg ) {ta1.value += "Y";}else{ta1.value += "y";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 18://boks26
		case 48:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/68.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/74.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/236.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/70.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/69.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/67.gif';
		if( 18 == arg ) {ta1.value += "Z";}else{ta1.value += "z";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 16:
		case 144://boks27
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/146.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/225.jpg';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/147.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		if( 16 == arg ) {ta1.value += "@";}else{ta1.value += "a";}
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 28:
		document[ 'foto1' ].src = 'https://sites.google.com/a/font77.com/font77/14.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/15.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/16.gif';		  
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/52.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/58.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/80.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 29:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/229.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/22.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/2.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 30:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/20.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/93.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/30.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/11.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/33.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/34.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 31:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/114.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/40.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/54.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/56.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/38.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/55.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/68.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/74.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/71.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/70.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/69.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/67.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 33:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/103.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/83.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/6.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/88.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/89.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 34:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/193.jpg';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/5.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/114.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 35:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/26.gif';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/169.gif';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/171.gif';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/178.gif';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/121.gif';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/166.gif';
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 36:
		document['foto1'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto2'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';
		document['foto3'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto4'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto5'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';		
		document['foto6'].src = 'https://sites.google.com/a/font77.com/font77/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
	}
}
function show7Voice(arg)
{
	switch (arg)
	{
		case 1:
		document['foto1'].src = '75.GIF';
		document['foto2'].src = '76.GIF';
		document['foto3'].src = '79.GIF';		
		document['foto4'].src = '80.GIF';		
		document['foto5'].src = '89.GIF';		
		document['foto6'].src = '93.GIF';
		break;
		case 2:
		document[ 'foto1' ].src = '12.GIF';
		document['foto2'].src = '13.GIF';
		document['foto3'].src = '14.GIF';		
		document['foto4'].src = '15.GIF';		
		document['foto5'].src = '16.GIF';		
		document['foto6'].src = '20.GIF';
		break;
		case 3:
		document['foto1'].src = '29.GIF';
		document['foto2'].src = '30.GIF';
		document['foto3'].src = '31.GIF';		
		document['foto4'].src = '32.GIF';		
		document['foto5'].src = '34.GIF';		
		document['foto6'].src = '39.GIF';
		break;
		case 4:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.GIF';
		document['foto3'].src = '121.GIF';
		document['foto4'].src = '120.GIF';
		document['foto5'].src = '119.GIF';		
		document['foto6'].src = '118.GIF';
		break;
		case 5:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 6:
		document['foto1'].src = '49.GIF';
		document['foto2'].src = '48.GIF';
		document['foto3'].src = '43.GIF';		
		document['foto4'].src = '42.GIF';		
		document['foto5'].src = '41.GIF';		
		document['foto6'].src = '37.GIF';
		break;
		case 7:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 8:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.GIF';
		document['foto2'].src = '169.GIF';
		document['foto3'].src = '171.GIF';		
		document['foto4'].src = '164.GIF';		
		document['foto5'].src = '170.GIF';
		break;
		case 9:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.GIF';		
		document['foto5'].src = '147.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 10:
		document['foto1'].src = '38.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 11:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 12:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 13:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.GIF';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.GIF';		
		document['foto5'].src = '160.GIF';		
		document['foto6'].src = '163.GIF';
		break;
		case 14:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.GIF';		
		document['foto4'].src = '40.GIF';		
		document['foto5'].src = '167.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 15:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 16:
		document['foto1'].src = '184.GIF';
		document['foto2'].src = '113.GIF';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.GIF';		
		document['foto5'].src = '110.GIF';		
		document['foto6'].src = '115.GIF';
		break;
		case 17:
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.GIF';
		document['foto3'].src = '114.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 18:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 19:
		document['foto1'].src = '52.GIF';
		document['foto2'].src = '53.GIF';
		document['foto3'].src = '54.GIF';		
		document['foto4'].src = '44.GIF';		
		document['foto5'].src = '47.GIF';		
		document['foto6'].src = '56.GIF';
		break;
		case 20:
		document['foto1'].src = '67.GIF';
		document['foto2'].src = '69.GIF';
		document['foto3'].src = '70.GIF';		
		document['foto4'].src = '71.GIF';		
		document['foto5'].src = '74.GIF';		
		document['foto6'].src = '72.GIF';
		break;
		case 21:
		document['foto1'].src = '22.GIF';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.GIF';		
		document['foto4'].src = '25.GIF';		
		document['foto5'].src = '23.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 22:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.GIF';
		document['foto3'].src = '94.GIF';		
		document['foto4'].src = '95.GIF';		
		document['foto5'].src = '96.GIF';		
		document['foto6'].src = '97.GIF';
		break;
		case 23:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 24:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 25:
		document['foto1'].src = '99.GIF';
		document['foto2'].src = '103.GIF';
		document['foto3'].src = '104.GIF';		
		document['foto4'].src = '106.GIF';		
		document['foto5'].src = '109.GIF';		
		document['foto6'].src = '101.GIF';
		break;
		case 26:
		document['foto1'].src = '44.GIF';
		document['foto2'].src = '151.GIF';
		document['foto3'].src = '175.GIF';		
		document['foto4'].src = '176.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 27:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 28:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.GIF';
		document['foto3'].src = '133.GIF';		
		document['foto4'].src = '136.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 29:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 30:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.GIF';
		document['foto3'].src = '57.GIF';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.GIF';		
		document['foto6'].src = '234.jpg';
		break;
		case 31:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.GIF';		
		document['foto4'].src = '4.GIF';		
		document['foto5'].src = '173.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 32:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 33:
		document['foto1'].src = '59.GIF';
		document['foto2'].src = '62.GIF';
		document['foto3'].src = '63.GIF';		
		document['foto4'].src = '64.GIF';		
		document['foto5'].src = '65.GIF';		
		document['foto6'].src = '66.GIF';
		break;
		case 34:
		document['foto1'].src = '138.GIF';
		document['foto2'].src = '139.GIF';
		document['foto3'].src = '157.GIF';		
		document['foto4'].src = '156.GIF';		
		document['foto5'].src = '152.GIF';		
		document['foto6'].src = '149.GIF';
		break;
		case 35:
		document['foto1'].src = '24.GIF';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 36:
		document['foto1'].src = '0.GIF';
		document['foto2'].src = '0.jpg';
		document['foto3'].src = '0.jpg';		
		document['foto4'].src = '0.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
	}
}
function complete7Voice(arg)
{
	switch (arg)
	{
		case 193:
		document['foto1'].src = '75.GIF';
		document['foto2'].src = '76.GIF';
		document['foto3'].src = '79.GIF';		
		document['foto4'].src = '80.GIF';		
		document['foto5'].src = '89.GIF';		
		document['foto6'].src = '93.GIF';
		break;
		case 140:
		document[ 'foto1' ].src = '12.GIF';
		document['foto2'].src = '13.GIF';
		document['foto3'].src = '14.GIF';		
		document['foto4'].src = '15.GIF';		
		document['foto5'].src = '16.GIF';		
		document['foto6'].src = '20.GIF';
		break;
		case 152:
		document['foto1'].src = '29.GIF';
		document['foto2'].src = '30.GIF';
		document['foto3'].src = '31.GIF';		
		document['foto4'].src = '32.GIF';		
		document['foto5'].src = '34.GIF';		
		document['foto6'].src = '39.GIF';
		break;
		case 131:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.GIF';
		document['foto3'].src = '121.GIF';
		document['foto4'].src = '120.GIF';
		document['foto5'].src = '119.GIF';		
		document['foto6'].src = '118.GIF';
		break;
		case 65:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 135:
		document['foto1'].src = '49.GIF';
		document['foto2'].src = '48.GIF';
		document['foto3'].src = '43.GIF';		
		document['foto4'].src = '42.GIF';		
		document['foto5'].src = '41.GIF';		
		document['foto6'].src = '37.GIF';
		break;
		case 192:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 132:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.GIF';
		document['foto2'].src = '169.GIF';
		document['foto3'].src = '171.GIF';		
		document['foto4'].src = '164.GIF';		
		document['foto5'].src = '170.GIF';
		break;
		case 144:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.GIF';		
		document['foto5'].src = '147.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 130:
		document['foto1'].src = '38.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 24:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 12:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 145:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.GIF';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.GIF';		
		document['foto5'].src = '160.GIF';		
		document['foto6'].src = '163.GIF';
		break;
		case 133:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.GIF';		
		document['foto4'].src = '40.GIF';		
		document['foto5'].src = '167.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 200:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 138:
		document['foto1'].src = '184.GIF';
		document['foto2'].src = '113.GIF';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.GIF';		
		document['foto5'].src = '110.GIF';		
		document['foto6'].src = '115.GIF';
		break;
		case 10:
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.GIF';
		document['foto3'].src = '114.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 4:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 164:
		document['foto1'].src = '52.GIF';
		document['foto2'].src = '53.GIF';
		document['foto3'].src = '54.GIF';		
		document['foto4'].src = '44.GIF';		
		document['foto5'].src = '47.GIF';		
		document['foto6'].src = '56.GIF';
		break;
		case 176:
		document['foto1'].src = '67.GIF';
		document['foto2'].src = '69.GIF';
		document['foto3'].src = '70.GIF';		
		document['foto4'].src = '71.GIF';		
		document['foto5'].src = '74.GIF';		
		document['foto6'].src = '72.GIF';
		break;
		case 224:
		document['foto1'].src = '22.GIF';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.GIF';		
		document['foto4'].src = '25.GIF';		
		document['foto5'].src = '23.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 162:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.GIF';
		document['foto3'].src = '94.GIF';		
		document['foto4'].src = '95.GIF';		
		document['foto5'].src = '96.GIF';		
		document['foto6'].src = '97.GIF';
		break;
		case 5:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 17:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 161:
		document['foto1'].src = '99.GIF';
		document['foto2'].src = '103.GIF';
		document['foto3'].src = '104.GIF';		
		document['foto4'].src = '106.GIF';		
		document['foto5'].src = '109.GIF';		
		document['foto6'].src = '101.GIF';
		break;
		case 168:
		document['foto1'].src = '44.GIF';
		document['foto2'].src = '151.GIF';
		document['foto3'].src = '175.GIF';		
		document['foto4'].src = '176.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 160:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 146:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.GIF';
		document['foto3'].src = '133.GIF';		
		document['foto4'].src = '136.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 48:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 36:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.GIF';
		document['foto3'].src = '57.GIF';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.GIF';		
		document['foto6'].src = '234.jpg';
		break;
		case 129:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.GIF';		
		document['foto4'].src = '4.GIF';		
		document['foto5'].src = '173.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 136:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 137:
		document['foto1'].src = '59.GIF';
		document['foto2'].src = '62.GIF';
		document['foto3'].src = '63.GIF';		
		document['foto4'].src = '64.GIF';		
		document['foto5'].src = '65.GIF';		
		document['foto6'].src = '66.GIF';
		break;
		case 196:
		document['foto1'].src = '138.GIF';
		document['foto2'].src = '139.GIF';
		document['foto3'].src = '157.GIF';		
		document['foto4'].src = '156.GIF';		
		document['foto5'].src = '152.GIF';		
		document['foto6'].src = '149.GIF';
		break;
		case 96:
		document['foto1'].src = '24.GIF';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;
		case 18:
		document['foto1'].src = '0.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
	}
}
function changeLanguage(langarg)
{
	switch(langarg)
	{
	case 0:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/hexnumbersChart.png';break;
	case 1:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/voiceChart.png';break;
	case 2:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/symbolsChart.png';break;
	case 3:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/englishChart.png';break;
	case 4:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/hinwicart.png';break;
	case 5:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/xelugucart.png';break;
	case 6:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/KnARacart.png';break;
	case 7:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/malayalamcart.png';break;
	case 8:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/tamilcart.png';break;
	case 9:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/oriyacart.png';break;
	case 10:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/banglacart.png';break;
	case 11:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/punjabicart.png';break;
	case 12:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/gujaraticart.png';break;
	default:document.aksrcart.src ='https://sites.google.com/a/font77.com/font77/0.GIF';break;
	}
	selectedlanguageindex =langarg;
	document['foto1'].src ='https://sites.google.com/a/font77.com/font77/0.gif';
	document['foto2'].src ='https://sites.google.com/a/font77.com/font77/0.gif';
	document['foto3'].src ='https://sites.google.com/a/font77.com/font77/0.gif';
	document['foto4'].src ='https://sites.google.com/a/font77.com/font77/0.gif';
	document['foto5'].src ='https://sites.google.com/a/font77.com/font77/0.gif';
	document['foto6'].src ='https://sites.google.com/a/font77.com/font77/0.gif';
	document.getElementById('foto1lbl').innerHTML = '';
	document.getElementById('foto1lb2').innerHTML = '';
	document.getElementById('foto1lb3').innerHTML = '';
	document.getElementById('foto1lb4').innerHTML = '';
	document.getElementById('foto1lb5').innerHTML = '';
	document.getElementById('foto1lb6').innerHTML = '';	
}
function handleCharClick(arg)
{
	switch (selectedlanguageindex)
	{
		case 0: showNmbrs(arg);break;
		case 1: show7Voice(arg);break;
		case 2: showSymbols(arg);break;
		case 3: showCharEnglish(arg);break;
		case 4: showCharHindi(arg);break;
		case 5: showCharTelugu(arg);break;
		case 6: showCharKannada(arg);break;
		case 7: showCharMalayalam(arg);break;
		case 8: showCharTamil(arg);break;
		case 9: showCharOriya(arg);break;
		case 10: showCharBangla(arg);break;
		case 11: showCharPunjabi(arg);break;
		case 12: showCharGujarati(arg);break;
	}
}