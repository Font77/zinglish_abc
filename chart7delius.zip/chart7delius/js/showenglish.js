function showCharEnglish(arg)
{//piqcrs
	switch (arg)
	{
		case 1:
		document['foto1'].src = 'piqcrs/arrow.gif';
		document['foto2'].src = 'piqcrs/apple.jpg';
		document['foto3'].src = 'piqcrs/umbrela.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		//document.all['BGSOUND_ID'].src='1.mp3';
		document.getElementById('foto1lbl').innerHTML = 'Aro';
		document.getElementById('foto1lb2').innerHTML = 'Appl';
		document.getElementById('foto1lb3').innerHTML = 'Ambrela';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 2:
		document[ 'foto1' ].src = 'piqcrs/burger.gif';
		document['foto2'].src = 'piqcrs/bread.gif';
		document['foto3'].src = 'piqcrs/bottle.gif';		  
		document['foto4'].src = 'piqcrs/baloon.gif';		
		document['foto5'].src = 'piqcrs/bell.gif';		
		document['foto6'].src = 'piqcrs/banana.gif';	
		document.all['BGSOUND_ID'].src='28.mp3';		
		document.getElementById('foto1lbl').innerHTML = 'brgr';
		document.getElementById('foto1lb2').innerHTML = 'brAd';
		document.getElementById('foto1lb3').innerHTML = 'botl';
		document.getElementById('foto1lb4').innerHTML = 'bAlun';
		document.getElementById('foto1lb5').innerHTML = 'bAl';
		document.getElementById('foto1lb6').innerHTML = 'bnana';
		break;		
		case 3:
		document['foto1'].src = 'piqcrs/chair.jpg';
		document['foto2'].src = 'piqcrs/cherry.gif';
		document['foto3'].src = 'piqcrs/chisel.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='13.mp3';		
		document.getElementById('foto1lbl').innerHTML = 'chair';
		document.getElementById('foto1lb2').innerHTML = 'cherry';
		document.getElementById('foto1lb3').innerHTML = 'chiesel';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 4:
		document['foto1'].src = 'piqcrs/drop.gif';
		document['foto2'].src = 'piqcrs/dog.gif';
		document['foto3'].src = 'piqcrs/desk.gif';		
		document['foto4'].src = 'piqcrs/duck.gif';		
		document['foto5'].src = 'piqcrs/dice.gif';		
		document['foto6'].src = 'piqcrs/drum.gif';
		document.all['BGSOUND_ID'].src='19.mp3';		
		document.getElementById('foto1lbl').innerHTML = 'drop';
		document.getElementById('foto1lb2').innerHTML = 'dog';
		document.getElementById('foto1lb3').innerHTML = 'desq';
		document.getElementById('foto1lb4').innerHTML = 'dq';
		document.getElementById('foto1lb5').innerHTML = 'dais';
		document.getElementById('foto1lb6').innerHTML = 'drm';
		break;		
		case 5:
		document['foto1'].src = 'piqcrs/elephant.gif';
		document['foto2'].src = 'piqcrs/elevator.jpg';
		document['foto3'].src = 'piqcrs/airbus.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='5.mp3';			
		document.getElementById('foto1lbl').innerHTML = 'elifAnt';
		document.getElementById('foto1lb2').innerHTML = 'elivetr';
		document.getElementById('foto1lb3').innerHTML = 'eyrbs';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 6:
		document['foto1'].src = 'piqcrs/flower.gif';
		document['foto2'].src = 'piqcrs/fish.gif';		
		document['foto3'].src = 'piqcrs/frog.gif';		
		document['foto4'].src = 'piqcrs/folder.gif';		
		document['foto5'].src = 'piqcrs/fork.gif';
		document['foto6'].src = 'piqcrs/funnel.gif';
		document.all['BGSOUND_ID'].src='27.mp3';		
		document.getElementById('foto1lbl').innerHTML = 'flovr';
		document.getElementById('foto1lb2').innerHTML = 'fis';
		document.getElementById('foto1lb3').innerHTML = 'frog';
		document.getElementById('foto1lb4').innerHTML = 'foldr';
		document.getElementById('foto1lb5').innerHTML = 'forq';
		document.getElementById('foto1lb6').innerHTML = 'fnAl';
		break;		
		case 7:
		document['foto1'].src = 'piqcrs/grapes.gif';
		document['foto2'].src = 'piqcrs/gloves.gif';
		document['foto3'].src = 'piqcrs/globe.gif';		
		document['foto4'].src = 'piqcrs/gift.gif';		
		document['foto5'].src = 'piqcrs/violin.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='10.mp3';	
		document.getElementById('foto1lbl').innerHTML = 'greps';
		document.getElementById('foto1lb2').innerHTML = 'glovs';
		document.getElementById('foto1lb3').innerHTML = 'glob';
		document.getElementById('foto1lb4').innerHTML = 'gift';
		document.getElementById('foto1lb5').innerHTML = 'gitar';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 8:
		document['foto1'].src = 'piqcrs/hairs.gif';
		document['foto2'].src = 'piqcrs/horn.gif';
		document['foto3'].src = 'piqcrs/hat.gif';		
		document['foto4'].src = 'piqcrs/horse.gif';		
		document['foto5'].src = 'piqcrs/helicopter.gif';		
		document['foto6'].src = 'piqcrs/hanger.gif';
		document.all['BGSOUND_ID'].src='36.mp3';		
		document.getElementById('foto1lbl').innerHTML = 'heyrs';
		document.getElementById('foto1lb2').innerHTML = 'horn';
		document.getElementById('foto1lb3').innerHTML = 'hAt';
		document.getElementById('foto1lb4').innerHTML = 'hors';
		document.getElementById('foto1lb5').innerHTML = 'heliqoptr';
		document.getElementById('foto1lb6').innerHTML = 'hANgr';
		break;
		case 9:
		document['foto1'].src = 'piqcrs/inkpot.jpg';
		document['foto2'].src = 'piqcrs/locomotive.jpg';
		document['foto3'].src = 'piqcrs/95.gif';		
		document['foto4'].src = 'piqcrs/75.gif';		
		document['foto5'].src = 'piqcrs/141.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='3.mp3';		
		document.getElementById('foto1lbl').innerHTML = 'iNq';
		document.getElementById('foto1lb2').innerHTML = 'injn';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 10:
		document['foto1'].src = 'piqcrs/68.gif';
		document['foto2'].src = 'piqcrs/74.gif';
		document['foto3'].src = 'piqcrs/71.gif';		
		document['foto4'].src = 'piqcrs/70.gif';		
		document['foto5'].src = 'piqcrs/69.gif';		
		document['foto6'].src = 'piqcrs/67.gif';
		document.all['BGSOUND_ID'].src='15.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 11:
		document['foto1'].src = 'piqcrs/103.gif';
		document['foto2'].src = 'piqcrs/89.gif';
		document['foto3'].src = 'piqcrs/83.gif';		
		document['foto4'].src = 'piqcrs/6.gif';		
		document['foto5'].src = 'piqcrs/88.gif';		
		document['foto6'].src = 'piqcrs/89.gif';
		document.all['BGSOUND_ID'].src='8.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 12:
		document['foto1'].src = 'piqcrs/159.gif';
		document['foto2'].src = 'piqcrs/149.gif';
		document['foto3'].src = 'piqcrs/113.gif';		
		document['foto4'].src = 'piqcrs/97.gif';		
		document['foto5'].src = 'piqcrs/65.gif';		
		document['foto6'].src = 'piqcrs/122.gif';
		document.all['BGSOUND_ID'].src='33.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 13:
		document['foto1'].src = 'piqcrs/108.gif';
		document['foto2'].src = 'piqcrs/104.gif';
		document['foto3'].src = 'piqcrs/18.gif';		
		document['foto4'].src = 'piqcrs/100.gif';		
		document['foto5'].src = 'piqcrs/102.gif';		
		//document['foto6'].src = 'piqcrs/205.jpg';
		document.all['BGSOUND_ID'].src='30.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 14:
		document['foto1'].src = 'piqcrs/200.jpg';
		document['foto2'].src = 'piqcrs/91.gif';
		document['foto3'].src = 'piqcrs/115.gif';		
		document['foto4'].src = 'piqcrs/234.jpg';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='25.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 15:
		document['foto1'].src = 'piqcrs/206.jpg';
		document['foto2'].src = 'piqcrs/202.jpg';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='6.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 16:
		document['foto1'].src = 'piqcrs/120.gif';
		document['foto2'].src = 'piqcrs/131.gif';
		document['foto3'].src = 'piqcrs/156.gif';		
		document['foto4'].src = 'piqcrs/132.gif';		
		document['foto5'].src = 'piqcrs/119.gif';		
		document['foto6'].src = 'piqcrs/111.gif';
		document.all['BGSOUND_ID'].src='26.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 17:
		document['foto1'].src = 'piqcrs/103.gif';
		document['foto2'].src = 'piqcrs/89.gif';
		document['foto3'].src = 'piqcrs/83.gif';		
		document['foto4'].src = 'piqcrs/6.gif';		
		document['foto5'].src = 'piqcrs/88.gif';		
		document['foto6'].src = 'piqcrs/89.gif';
		document.all['BGSOUND_ID'].src='8.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 18:
		document['foto1'].src = 'piqcrs/45.gif';
		document['foto2'].src = 'piqcrs/133.gif';
		document['foto3'].src = 'piqcrs/5.gif';		
		document['foto4'].src = 'piqcrs/8.gif';		
		document['foto5'].src = 'piqcrs/137.gif';		
		document['foto6'].src = 'piqcrs/43.gif';
		document.all['BGSOUND_ID'].src='32.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 19:
		document['foto1'].src = 'piqcrs/23.gif';
		document['foto2'].src = 'piqcrs/25.gif';
		document['foto3'].src = 'piqcrs/139.gif';		
		document['foto4'].src = 'piqcrs/140.gif';		
		document['foto5'].src = 'piqcrs/107.gif';		
		document['foto6'].src = 'piqcrs/157.gif';
		document.all['BGSOUND_ID'].src='35.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 20:
		document['foto1'].src = 'piqcrs/26.gif';
		document['foto2'].src = 'piqcrs/169.gif';
		document['foto3'].src = 'piqcrs/171.gif';		
		document['foto4'].src = 'piqcrs/178.gif';		
		document['foto5'].src = 'piqcrs/121.gif';		
		document['foto6'].src = 'piqcrs/166.gif';
		document.all['BGSOUND_ID'].src='17.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 21:
		document['foto1'].src = 'piqcrs/0.gif';
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='4.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 22:
		document['foto1'].src = 'piqcrs/44.gif';
		document['foto2'].src = 'piqcrs/176.gif';
		document['foto3'].src = 'piqcrs/73.gif';		
		document['foto4'].src = 'piqcrs/175.gif';		
		document['foto5'].src = 'piqcrs/160.gif';		
		document['foto6'].src = 'piqcrs/152.gif';
		document.all['BGSOUND_ID'].src='34.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 23:
		document['foto1'].src = 'piqcrs/44.gif';
		document['foto2'].src = 'piqcrs/176.gif';
		document['foto3'].src = 'piqcrs/73.gif';		
		document['foto4'].src = 'piqcrs/175.gif';		
		document['foto5'].src = 'piqcrs/160.gif';		
		document['foto6'].src = 'piqcrs/152.gif';
		document.all['BGSOUND_ID'].src='34.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 24:
		document['foto1'].src = 'piqcrs/237.gif';
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		//document.all['BGSOUND_ID'].src='34.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 25:
		document['foto1'].src = 'piqcrs/177.gif';
		document['foto2'].src = 'piqcrs/199.jpg';
		document['foto3'].src = 'piqcrs/198.jpg';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='31.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 26:
		document['foto1'].src = 'piqcrs/68.gif';
		document['foto2'].src = 'piqcrs/74.gif';
		document['foto3'].src = 'piqcrs/236.gif';		
		document['foto4'].src = 'piqcrs/70.gif';		
		document['foto5'].src = 'piqcrs/69.gif';		
		document['foto6'].src = 'piqcrs/67.gif';
		document.all['BGSOUND_ID'].src='15.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 27:
		document['foto1'].src = 'piqcrs/146.gif';
		document['foto2'].src = 'piqcrs/225.jpg';
		document['foto3'].src = 'piqcrs/147.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='2.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 28:
		document[ 'foto1' ].src = 'piqcrs/14.gif';
		document['foto2'].src = 'piqcrs/15.gif';
		document['foto3'].src = 'piqcrs/16.gif';		  
		document['foto4'].src = 'piqcrs/52.gif';		
		document['foto5'].src = 'piqcrs/58.gif';		
		document['foto6'].src = 'piqcrs/80.gif';
		document.all['BGSOUND_ID'].src='29.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 29:
		document['foto1'].src = 'piqcrs/229.jpg';
		document['foto2'].src = 'piqcrs/22.gif';
		document['foto3'].src = 'piqcrs/2.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='14.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 30:
		document['foto1'].src = 'piqcrs/20.gif';
		document['foto2'].src = 'piqcrs/93.gif';
		document['foto3'].src = 'piqcrs/30.gif';		
		document['foto4'].src = 'piqcrs/11.gif';		
		document['foto5'].src = 'piqcrs/33.gif';		
		document['foto6'].src = 'piqcrs/34.gif';
		document.all['BGSOUND_ID'].src='20.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 31:
		document['foto1'].src = 'piqcrs/114.gif';
		document['foto2'].src = 'piqcrs/40.gif';
		document['foto3'].src = 'piqcrs/54.gif';		
		document['foto4'].src = 'piqcrs/56.gif';		
		document['foto5'].src = 'piqcrs/38.gif';		
		document['foto6'].src = 'piqcrs/55.gif';
		document.all['BGSOUND_ID'].src='11.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32:
		document['foto1'].src = 'piqcrs/68.gif';
		document['foto2'].src = 'piqcrs/74.gif';
		document['foto3'].src = 'piqcrs/71.gif';		
		document['foto4'].src = 'piqcrs/70.gif';		
		document['foto5'].src = 'piqcrs/69.gif';		
		document['foto6'].src = 'piqcrs/67.gif';
		document.all['BGSOUND_ID'].src='16.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 33:
		document['foto1'].src = 'piqcrs/103.gif';
		document['foto2'].src = 'piqcrs/89.gif';
		document['foto3'].src = 'piqcrs/83.gif';		
		document['foto4'].src = 'piqcrs/6.gif';		
		document['foto5'].src = 'piqcrs/88.gif';		
		document['foto6'].src = 'piqcrs/89.gif';
		document.all['BGSOUND_ID'].src='9.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 34:
		document['foto1'].src = 'piqcrs/193.jpg';
		document['foto2'].src = 'piqcrs/5.gif';
		document['foto3'].src = 'piqcrs/114.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='7.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 35:
		document['foto1'].src = 'piqcrs/26.gif';
		document['foto2'].src = 'piqcrs/169.gif';
		document['foto3'].src = 'piqcrs/171.gif';		
		document['foto4'].src = 'piqcrs/178.gif';		
		document['foto5'].src = 'piqcrs/121.gif';		
		document['foto6'].src = 'piqcrs/166.gif';
		document.all['BGSOUND_ID'].src='18.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 36:
		document['foto1'].src = 'piqcrs/0.gif';
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	/*	
		case "th":
		document['foto1'].src = 'piqcrs/26.gif';
		document['foto2'].src = 'piqcrs/169.gif';
		document['foto3'].src = 'piqcrs/171.gif';		
		document['foto4'].src = 'piqcrs/178.gif';		
		document['foto5'].src = 'piqcrs/121.gif';		
		document['foto6'].src = 'piqcrs/166.gif';					
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case "tt":
		document['foto1'].src = 'piqcrs/193.jpg';
		document['foto2'].src = 'piqcrs/192.jpg';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case "tth":
		document['foto1'].src = 'piqcrs/193.jpg';
		document['foto2'].src = 'piqcrs/192.jpg';
		document['foto3'].src = 'piqcrs/209.jpg';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break; */
	}
}

function completeCharEnglish(arg)
{
	switch (arg)
	{
		case 129://boks1
		document['foto1'].src = 'piqcrs/173.gif';
		document['foto2'].src = 'piqcrs/231.jpg';
		document['foto3'].src = 'piqcrs/24.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		//alert("hello");
		ta1.value += "A";
		//alert(ta1.value);		
		document.all['BGSOUND_ID'].src='1.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 140:
		document[ 'foto1' ].src = 'piqcrs/14.gif';
		document['foto2'].src = 'piqcrs/15.gif';
		document['foto3'].src = 'piqcrs/16.gif';		  
		document['foto4'].src = 'piqcrs/52.gif';		
		document['foto5'].src = 'piqcrs/58.gif';		
		document['foto6'].src = 'piqcrs/80.gif';
		ta1.value += "b";
		document.all['BGSOUND_ID'].src='28.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 166://boks3
		case 158:
		document['foto1'].src = 'piqcrs/229.jpg';
		document['foto2'].src = 'piqcrs/22.gif';
		document['foto3'].src = 'piqcrs/2.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		ta1.value += "c";
		document.all['BGSOUND_ID'].src='13.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 152://boks4
		document['foto1'].src = 'piqcrs/20.gif';
		document['foto2'].src = 'piqcrs/93.gif';
		document['foto3'].src = 'piqcrs/30.gif';		
		document['foto4'].src = 'piqcrs/11.gif';		
		document['foto5'].src = 'piqcrs/33.gif';		
		document['foto6'].src = 'piqcrs/34.gif';
		ta1.value += "d";
		document.all['BGSOUND_ID'].src='19.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 130://boks5 E
		case 134://boks5 e
		document['foto1'].src = 'piqcrs/3.gif';
		document['foto2'].src = 'piqcrs/59.gif';
		document['foto3'].src = 'piqcrs/66.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 130 == arg ) {ta1.value += "e";}else{ta1.value += "E";}
		document.all['BGSOUND_ID'].src='5.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 7:
		case 135://boks6 F
		document['foto1'].src = 'piqcrs/42.gif';
		document['foto2'].src = 'piqcrs/99.gif';		
		document['foto3'].src = 'piqcrs/106.gif';		
		document['foto4'].src = 'piqcrs/48.gif';		
		document['foto5'].src = 'piqcrs/78.gif';
		document['foto6'].src = 'piqcrs/180.gif';
		if( 135 == arg ) {ta1.value += "f";}else{ta1.value += "F";}
		document.all['BGSOUND_ID'].src='27.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 36:
		case 164://boks7 G
		document['foto1'].src = 'piqcrs/114.gif';
		document['foto2'].src = 'piqcrs/40.gif';
		document['foto3'].src = 'piqcrs/54.gif';		
		document['foto4'].src = 'piqcrs/56.gif';		
		document['foto5'].src = 'piqcrs/38.gif';		
		document['foto6'].src = 'piqcrs/55.gif';
		if( 164 == arg ) {ta1.value += "g";}else{ta1.value += "G";}
		document.all['BGSOUND_ID'].src='10.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 137://boks8
		case 141://boks8
		document['foto1'].src = 'piqcrs/7.gif';
		document['foto2'].src = 'piqcrs/64.gif';
		document['foto3'].src = 'piqcrs/170.gif';		
		document['foto4'].src = 'piqcrs/57.gif';		
		document['foto5'].src = 'piqcrs/62.gif';		
		document['foto6'].src = 'piqcrs/63.gif';
		if( 137 == arg ) {ta1.value += "H";}else{ta1.value += "h";}
		document.all['BGSOUND_ID'].src='36.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 192://boks9
		case 253://boks9
		document['foto1'].src = 'piqcrs/189.jpg';
		document['foto2'].src = 'piqcrs/187.jpg';
		document['foto3'].src = 'piqcrs/95.gif';		
		document['foto4'].src = 'piqcrs/75.gif';		
		document['foto5'].src = 'piqcrs/141.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 192 == arg ) {ta1.value += "I";}else{ta1.value += "i";}
		document.all['BGSOUND_ID'].src='3.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 184://boks10
		case 176://boks10
		document['foto1'].src = 'piqcrs/68.gif';
		document['foto2'].src = 'piqcrs/74.gif';
		document['foto3'].src = 'piqcrs/71.gif';		
		document['foto4'].src = 'piqcrs/70.gif';		
		document['foto5'].src = 'piqcrs/69.gif';		
		document['foto6'].src = 'piqcrs/67.gif';
		if( 137 == arg ) {ta1.value += "J";}else{ta1.value += "J";}
		document.all['BGSOUND_ID'].src='15.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 193://boks11
		case 143://boks11
		document['foto1'].src = 'piqcrs/103.gif';
		document['foto2'].src = 'piqcrs/89.gif';
		document['foto3'].src = 'piqcrs/83.gif';		
		document['foto4'].src = 'piqcrs/6.gif';		
		document['foto5'].src = 'piqcrs/88.gif';		
		document['foto6'].src = 'piqcrs/89.gif';
		if( 143 == arg ) {ta1.value += "K";}else{ta1.value += "q";}
		document.all['BGSOUND_ID'].src='8.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 174://boks12
		case 162://boks12
		document['foto1'].src = 'piqcrs/159.gif';
		document['foto2'].src = 'piqcrs/149.gif';
		document['foto3'].src = 'piqcrs/113.gif';		
		document['foto4'].src = 'piqcrs/97.gif';		
		document['foto5'].src = 'piqcrs/65.gif';		
		document['foto6'].src = 'piqcrs/122.gif';
		if( 162 == arg ) {ta1.value += "L";}else{ta1.value += "L";}
		document.all['BGSOUND_ID'].src='33.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 33:
		case 161://boks13
		document['foto1'].src = 'piqcrs/108.gif';
		document['foto2'].src = 'piqcrs/205.jpg';
		document['foto3'].src = 'piqcrs/18.gif';		
		document['foto4'].src = 'piqcrs/100.gif';		
		document['foto5'].src = 'piqcrs/102.gif';		
		document['foto6'].src = 'piqcrs/104.gif';
		if( 33 == arg ) {ta1.value += "M";}else{ta1.value += "m";}
		document.all['BGSOUND_ID'].src='30.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 157://boks14
		case 138://boks14
		document['foto1'].src = 'piqcrs/200.jpg';
		document['foto2'].src = 'piqcrs/91.gif';
		document['foto3'].src = 'piqcrs/115.gif';		
		document['foto4'].src = 'piqcrs/234.jpg';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 138 == arg ) {ta1.value += "N";}else{ta1.value += "n";}
		document.all['BGSOUND_ID'].src='25.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32://boks15
		case 160://boks15
		document['foto1'].src = 'piqcrs/206.jpg';
		document['foto2'].src = 'piqcrs/202.jpg';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 32 == arg ) {ta1.value += "O";}else{ta1.value += "o";}
		document.all['BGSOUND_ID'].src='6.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 131://boks16
		document['foto1'].src = 'piqcrs/120.gif';
		document['foto2'].src = 'piqcrs/131.gif';
		document['foto3'].src = 'piqcrs/156.gif';		
		document['foto4'].src = 'piqcrs/132.gif';		
		document['foto5'].src = 'piqcrs/119.gif';		
		document['foto6'].src = 'piqcrs/111.gif';
		if( 131 == arg ) {ta1.value += "P";}else{ta1.value += "P";}
		document.all['BGSOUND_ID'].src='26.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 65:
		case 193://boks17
		document['foto1'].src = 'piqcrs/103.gif';
		document['foto2'].src = 'piqcrs/89.gif';
		document['foto3'].src = 'piqcrs/83.gif';		
		document['foto4'].src = 'piqcrs/6.gif';		
		document['foto5'].src = 'piqcrs/88.gif';		
		document['foto6'].src = 'piqcrs/89.gif';
		if( 65 == arg ) {ta1.value += "Q";}else{ta1.value += "q";}
		document.all['BGSOUND_ID'].src='8.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 146://boks18  R
		case 159://boks18 r
		document['foto1'].src = 'piqcrs/45.gif';
		document['foto2'].src = 'piqcrs/133.gif';
		document['foto3'].src = 'piqcrs/5.gif';		
		document['foto4'].src = 'piqcrs/8.gif';		
		document['foto5'].src = 'piqcrs/137.gif';		
		document['foto6'].src = 'piqcrs/43.gif';
		if( 146 == arg ) {ta1.value += "R";}else{ta1.value += "r";}
		document.all['BGSOUND_ID'].src='32.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 68: //S
		case 196://boks19 s
		document['foto1'].src = 'piqcrs/23.gif';
		document['foto2'].src = 'piqcrs/25.gif';
		document['foto3'].src = 'piqcrs/139.gif';		
		document['foto4'].src = 'piqcrs/140.gif';		
		document['foto5'].src = 'piqcrs/107.gif';		
		document['foto6'].src = 'piqcrs/157.gif';
		if( 68 == arg ) {ta1.value += "S";}else{ta1.value += "s";}
		document.all['BGSOUND_ID'].src='35.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 14://T
		case 142://boks20 t
		document['foto1'].src = 'piqcrs/26.gif';
		document['foto2'].src = 'piqcrs/169.gif';
		document['foto3'].src = 'piqcrs/171.gif';		
		document['foto4'].src = 'piqcrs/178.gif';		
		document['foto5'].src = 'piqcrs/121.gif';		
		document['foto6'].src = 'piqcrs/166.gif';
		if( 14 == arg ) {ta1.value += "T";}else{ta1.value += "t";}
		document.all['BGSOUND_ID'].src='17.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 136://boks21 U
		case 188://boks21 u
		document['foto1'].src = 'piqcrs/0.gif';
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 136 == arg ) {ta1.value += "U";}else{ta1.value += "u";}
		document.all['BGSOUND_ID'].src='4.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 40:
		case 168://boks22
		document['foto1'].src = 'piqcrs/44.gif';
		document['foto2'].src = 'piqcrs/176.gif';
		document['foto3'].src = 'piqcrs/73.gif';		
		document['foto4'].src = 'piqcrs/175.gif';		
		document['foto5'].src = 'piqcrs/160.gif';		
		document['foto6'].src = 'piqcrs/152.gif';
		if( 40 == arg ) {ta1.value += "W";}else{ta1.value += "V";}
		document.all['BGSOUND_ID'].src='34.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
/*		case 40://boks23
		document['foto1'].src = 'piqcrs/44.gif';
		document['foto2'].src = 'piqcrs/176.gif';
		document['foto3'].src = 'piqcrs/73.gif';		
		document['foto4'].src = 'piqcrs/175.gif';		
		document['foto5'].src = 'piqcrs/160.gif';		
		document['foto6'].src = 'piqcrs/152.gif';
		document.all['BGSOUND_ID'].src='34.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;*/
		case 15://boks24 x
		case 65://boks24 X
		document['foto1'].src = 'piqcrs/237.gif';
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 15 == arg ) {ta1.value += "x";}else{ta1.value += "X";}
		//document.all['BGSOUND_ID'].src='34.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 72:
		case 200://boks25
		document['foto1'].src = 'piqcrs/177.gif';
		document['foto2'].src = 'piqcrs/199.jpg';
		document['foto3'].src = 'piqcrs/198.jpg';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 72 == arg ) {ta1.value += "Y";}else{ta1.value += "y";}
		document.all['BGSOUND_ID'].src='31.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 18://boks26
		case 48:
		document['foto1'].src = 'piqcrs/68.gif';
		document['foto2'].src = 'piqcrs/74.gif';
		document['foto3'].src = 'piqcrs/236.gif';		
		document['foto4'].src = 'piqcrs/70.gif';		
		document['foto5'].src = 'piqcrs/69.gif';		
		document['foto6'].src = 'piqcrs/67.gif';
		if( 18 == arg ) {ta1.value += "Z";}else{ta1.value += "z";}
		document.all['BGSOUND_ID'].src='15.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 16:
		case 144://boks27
		document['foto1'].src = 'piqcrs/146.gif';
		document['foto2'].src = 'piqcrs/225.jpg';
		document['foto3'].src = 'piqcrs/147.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		if( 16 == arg ) {ta1.value += "@";}else{ta1.value += "a";}
		document.all['BGSOUND_ID'].src='2.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 28:
		document[ 'foto1' ].src = 'piqcrs/14.gif';
		document['foto2'].src = 'piqcrs/15.gif';
		document['foto3'].src = 'piqcrs/16.gif';		  
		document['foto4'].src = 'piqcrs/52.gif';		
		document['foto5'].src = 'piqcrs/58.gif';		
		document['foto6'].src = 'piqcrs/80.gif';
		document.all['BGSOUND_ID'].src='29.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 29:
		document['foto1'].src = 'piqcrs/229.jpg';
		document['foto2'].src = 'piqcrs/22.gif';
		document['foto3'].src = 'piqcrs/2.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='14.mp3';	
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 30:
		document['foto1'].src = 'piqcrs/20.gif';
		document['foto2'].src = 'piqcrs/93.gif';
		document['foto3'].src = 'piqcrs/30.gif';		
		document['foto4'].src = 'piqcrs/11.gif';		
		document['foto5'].src = 'piqcrs/33.gif';		
		document['foto6'].src = 'piqcrs/34.gif';
		document.all['BGSOUND_ID'].src='20.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 31:
		document['foto1'].src = 'piqcrs/114.gif';
		document['foto2'].src = 'piqcrs/40.gif';
		document['foto3'].src = 'piqcrs/54.gif';		
		document['foto4'].src = 'piqcrs/56.gif';		
		document['foto5'].src = 'piqcrs/38.gif';		
		document['foto6'].src = 'piqcrs/55.gif';
		document.all['BGSOUND_ID'].src='11.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32:
		document['foto1'].src = 'piqcrs/68.gif';
		document['foto2'].src = 'piqcrs/74.gif';
		document['foto3'].src = 'piqcrs/71.gif';		
		document['foto4'].src = 'piqcrs/70.gif';		
		document['foto5'].src = 'piqcrs/69.gif';		
		document['foto6'].src = 'piqcrs/67.gif';
		document.all['BGSOUND_ID'].src='16.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 33:
		document['foto1'].src = 'piqcrs/103.gif';
		document['foto2'].src = 'piqcrs/89.gif';
		document['foto3'].src = 'piqcrs/83.gif';		
		document['foto4'].src = 'piqcrs/6.gif';		
		document['foto5'].src = 'piqcrs/88.gif';		
		document['foto6'].src = 'piqcrs/89.gif';
		document.all['BGSOUND_ID'].src='9.mp3';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 34:
		document['foto1'].src = 'piqcrs/193.jpg';
		document['foto2'].src = 'piqcrs/5.gif';
		document['foto3'].src = 'piqcrs/114.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.all['BGSOUND_ID'].src='7.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 35:
		document['foto1'].src = 'piqcrs/26.gif';
		document['foto2'].src = 'piqcrs/169.gif';
		document['foto3'].src = 'piqcrs/171.gif';		
		document['foto4'].src = 'piqcrs/178.gif';		
		document['foto5'].src = 'piqcrs/121.gif';		
		document['foto6'].src = 'piqcrs/166.gif';
		document.all['BGSOUND_ID'].src='18.mp3';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	
		case 36:
		document['foto1'].src = 'piqcrs/0.gif';
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;	/*	
		case "th":
		document['foto1'].src = 'piqcrs/26.gif';
		document['foto2'].src = 'piqcrs/169.gif';
		document['foto3'].src = 'piqcrs/171.gif';		
		document['foto4'].src = 'piqcrs/178.gif';		
		document['foto5'].src = 'piqcrs/121.gif';		
		document['foto6'].src = 'piqcrs/166.gif';					
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case "tt":
		document['foto1'].src = 'piqcrs/193.jpg';
		document['foto2'].src = 'piqcrs/192.jpg';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';		
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case "tth":
		document['foto1'].src = 'piqcrs/193.jpg';
		document['foto2'].src = 'piqcrs/192.jpg';
		document['foto3'].src = 'piqcrs/209.jpg';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';			
		document.getElementById('foto1lbl').innerHTML = '';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break; */
	}
}