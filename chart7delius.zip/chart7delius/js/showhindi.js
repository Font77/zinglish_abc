function showCharHindi(arg)
{//alert('showCharHindi(arg) '+arg);
	switch (arg)
	{
		case 1://///AAAAAAAA
		document['foto1'].src = 'piqcrs/pomegranate.jpg';//pomegranate=Anar
		document['foto2'].src = 'piqcrs/ginger.jpg';//ginger=Awrk
		document['foto3'].src = 'piqcrs/egg.gif';//egg=Anda
		document['foto4'].src = 'piqcrs/pineapple.gif';//pineapple=Ananas
		document['foto5'].src = 'piqcrs/arrow.gif';//arrow=Aro
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'Anar';
		document.getElementById('foto1lb2').innerHTML = 'ADrAk';
		document.getElementById('foto1lb3').innerHTML = 'Anda';
		document.getElementById('foto1lb4').innerHTML = 'Ananas';
		document.getElementById('foto1lb5').innerHTML = 'AAro';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 2:///////aaaaaaaa
		document['foto1'].src = 'piqcrs/potato.jpg';//potato=alu
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/mango.jpg';//mango=am
		document['foto4'].src = 'piqcrs/eye.gif';//eye=aK	
		document['foto5'].src = 'piqcrs/icecream.gif';//icecream=aiskrim
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'aalu';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = 'aam';
		document.getElementById('foto1lb4').innerHTML = 'aakh';
		document.getElementById('foto1lb5').innerHTML = 'aiskrim';	
		break;
		case 3://///////iiiiiiiii
		document['foto1'].src = 'piqcrs/tamarind.jpg';//tamarind=imli
		document['foto2'].src = 'piqcrs/brick.jpg';//brick=iit
		document['foto3'].src = 'piqcrs/sugarcane.jpg';//sugarcane=iiK
		document['foto4'].src = 'piqcrs/locomotive.jpg';//locomotive=injn
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'imli';
		document.getElementById('foto1lb2').innerHTML = 'iit';
		document.getElementById('foto1lb3').innerHTML = 'iikh';
		document.getElementById('foto1lb4').innerHTML = 'injn';
		document.getElementById('foto1lb5').innerHTML = '';		
		break;
		case 4:////////uuuuuuuu
		document['foto1'].src = 'piqcrs/owl.jpg';//owl=ullu
		document['foto2'].src = 'piqcrs/camel1.jpg';//camel1=uut1
		document['foto3'].src = 'piqcrs/camel2.gif';//camel2=uut2
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'ullu';
		document.getElementById('foto1lb2').innerHTML = 'uut';
		document.getElementById('foto1lb3').innerHTML = 'uut';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		break;
		case 5://///eeeeeeeee
		document['foto1'].src = 'piqcrs/specs.gif';//specs=enq
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'enAk';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 6://///ooooooo
		document['foto1'].src = 'piqcrs/okhla.jpg';//okhla=oKla
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'okhla';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';		
		break;
		case 7: //qqqqq
		document['foto1'].src = 'piqcrs/ear.gif';//ear=qan
		document['foto2'].src = 'piqcrs/qar.gif';//qar
		document['foto3'].src = 'piqcrs/qeq.gif';//qeq		
		document['foto4'].src = 'piqcrs/banana.gif';//banana=qela		
		document['foto5'].src = 'piqcrs/cup.gif';//qp		
		document['foto6'].src = 'piqcrs/dog.gif';//dog=quxxa
		document.getElementById('foto1lbl').innerHTML = 'kan';
		document.getElementById('foto1lb2').innerHTML = 'kar';
		document.getElementById('foto1lb3').innerHTML = 'kek';
		document.getElementById('foto1lb4').innerHTML = 'kela';
		document.getElementById('foto1lb5').innerHTML = 'kp';	
		document.getElementById('foto1lb6').innerHTML = 'kuTTa';	
		break;		
		case 8:
		document['foto1'].src = 'piqcrs/hare.jpg';//hare=QrgoS
		document['foto2'].src = 'piqcrs/player.gif';//player=QilaRi
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'khrgosh';
		document.getElementById('foto1lb2').innerHTML = 'khilarri';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 9:
		document['foto1'].src = 'piqcrs/baloon.gif';//baloon=gubbara
		document['foto2'].src = 'piqcrs/cauliflower.gif';//cauliflower=goBi
		document['foto3'].src = 'piqcrs/globe.gif';//glob		
		document['foto4'].src = 'piqcrs/van.gif';//van=gaRi		
		document['foto5'].src = 'piqcrs/cow.gif';//cow=gay	
		document['foto6'].src = 'piqcrs/gift.gif';//gift
		document.getElementById('foto1lbl').innerHTML = 'gubbara';
		document.getElementById('foto1lb2').innerHTML = 'gobhi';
		document.getElementById('foto1lb3').innerHTML = 'glob';
		document.getElementById('foto1lb4').innerHTML = 'garri';
		document.getElementById('foto1lb5').innerHTML = 'gay';
		document.getElementById('foto1lb6').innerHTML = 'gipht';
		break;
		case 10:
		document['foto1'].src = 'piqcrs/house.jpg';//house=Gr
		document['foto2'].src = 'piqcrs/clock.gif';//clock=GRi
		document['foto3'].src = 'piqcrs/horse.gif';//horse=GoRa		
		document['foto4'].src = 'piqcrs/bottlegourd.jpg';//bottlegourd=Giya		
		document['foto5'].src = 'piqcrs/bell.gif';//bell=Gnti		
		document['foto6'].src = 'piqcrs/nest.jpg';//nest=Gosla
		document.getElementById('foto1lbl').innerHTML = 'ghr';
		document.getElementById('foto1lb2').innerHTML = 'ghrri';
		document.getElementById('foto1lb3').innerHTML = 'ghorra';
		document.getElementById('foto1lb4').innerHTML = 'ghiya';
		document.getElementById('foto1lb5').innerHTML = 'ghnti';		
		document.getElementById('foto1lb6').innerHTML = 'ghosla';		
		break;
		case 11:
		document['foto1'].src = 'piqcrs/cherry.gif';//cherry
		document['foto2'].src = 'piqcrs/sleeper.jpg';//sleeper=cppl
		document['foto3'].src = 'piqcrs/key.gif';//key=cabi	
		document['foto4'].src = 'piqcrs/sparrow.gif';//sparrow=ciRiya	
		document['foto5'].src = 'piqcrs/spoon.gif';//spoon=cmmc	
		document['foto6'].src = 'piqcrs/0.gif';//
		document.getElementById('foto1lbl').innerHTML = 'cheri';
		document.getElementById('foto1lb2').innerHTML = 'chppl';
		document.getElementById('foto1lb3').innerHTML = 'chabi';
		document.getElementById('foto1lb4').innerHTML = 'chirriya';
		document.getElementById('foto1lb5').innerHTML = 'cmmc';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 12:
		document['foto1'].src = 'piqcrs/umbrela.gif';//umbrela=Cxri
		document['foto2'].src = 'piqcrs/bananapeel.jpg';//bananapeel=Cilqa
		document['foto3'].src = 'piqcrs/basket.jpg';//basket=CbRi		
		document['foto4'].src = 'piqcrs/lizard.jpg';//lizard=CipAqli
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'chTri';
		document.getElementById('foto1lb2').innerHTML = 'Chilka';
		document.getElementById('foto1lb3').innerHTML = 'chbrri';
		document.getElementById('foto1lb4').innerHTML = 'chipAkli';
		document.getElementById('foto1lb5').innerHTML = '';		
		document.getElementById('foto1lb6').innerHTML = '';	
		break;      
		case 13:
		document['foto1'].src = 'piqcrs/jug.gif';//jug=jg
		document['foto2'].src = 'piqcrs/jacket.gif';//jacket=jAqet
		document['foto3'].src = 'piqcrs/jeep.gif';//jeep=jiip		
		document['foto4'].src = 'piqcrs/jeans.gif';//jeans=jiins		
		document['foto5'].src = 'piqcrs/giraffe.gif';//jiraf		
		document['foto6'].src = 'piqcrs/spidernet.gif';//jal
		document.getElementById('foto1lbl').innerHTML = 'zug';
		document.getElementById('foto1lb2').innerHTML = 'zAket';
		document.getElementById('foto1lb3').innerHTML = 'ziip';
		document.getElementById('foto1lb4').innerHTML = 'ziins';
		document.getElementById('foto1lb5').innerHTML = 'ziraph';
		document.getElementById('foto1lb6').innerHTML = 'zal';
		break;	
		case 14:
		document['foto1'].src = 'piqcrs/Jula.jpg';//Jula
		document['foto2'].src = 'piqcrs/waterfall.jpg';//Jrna
		document['foto3'].src = 'piqcrs/flag.jpg';//Jnda	
		document['foto4'].src = 'piqcrs/hut.jpg';//JopRi	
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'jhula';
		document.getElementById('foto1lb2').innerHTML = 'jhrna';
		document.getElementById('foto1lb3').innerHTML = 'jhnda';
		document.getElementById('foto1lb4').innerHTML = 'jhoprri';
		document.getElementById('foto1lb5').innerHTML = '';	
		document.getElementById('foto1lb6').innerHTML = '';	
		break;		
		case 15:////tttttttt
		document['foto1'].src = 'piqcrs/tomato.jpg';//tmatr		
		document['foto2'].src = 'piqcrs/tub.gif';//tb
		document['foto3'].src = 'piqcrs/torch.gif';//torc
		document['foto4'].src = 'piqcrs/tofi.gif';//tofi	
		document['foto5'].src = 'piqcrs/cap.gif';//topi	
		document['foto6'].src = 'piqcrs/tv.gif';//tivi
		document.getElementById('foto1lbl').innerHTML = 'tmatr';
		document.getElementById('foto1lb2').innerHTML = 'tub';
		document.getElementById('foto1lb3').innerHTML = 'torch';
		document.getElementById('foto1lb4').innerHTML = 'tofi';
		document.getElementById('foto1lb5').innerHTML = 'topi';
		document.getElementById('foto1lb6').innerHTML = 'tivi';
		break;	
		case 16:
		document['foto1'].src = 'piqcrs/blacksmith.jpg';//TTera
		document['foto2'].src = 'piqcrs/cart.gif';//thela
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'ththera';
		document.getElementById('foto1lb2').innerHTML = 'thela';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';				
		document.getElementById('foto1lb6').innerHTML = '';				
		break;		
		case 17:
		document['foto1'].src = 'piqcrs/dumble.gif';//dmbl
		document['foto2'].src = 'piqcrs/desk.gif';//desq
		document['foto3'].src = 'piqcrs/dynasore.gif';//daynasor		
		document['foto4'].src = 'piqcrs/dancer.gif';//dancer=dansr		
		document['foto5'].src = 'piqcrs/drum.gif';//drum=drm		
		document['foto6'].src = 'piqcrs/39.gif';
		document.getElementById('foto1lbl').innerHTML = 'dmbl';
		document.getElementById('foto1lb2').innerHTML = 'desk';
		document.getElementById('foto1lb3').innerHTML = 'daynasor';
		document.getElementById('foto1lb4').innerHTML = 'dansr';
		document.getElementById('foto1lb5').innerHTML = 'drm';
		break;		
		case 18:
		document['foto1'].src = 'piqcrs/lid.jpg';//dhakkan
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'dhkkn';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';		
		document.getElementById('foto1lb6').innerHTML = '';		
		break;
		case 19:
		document['foto1'].src = 'piqcrs/ridgegourd.jpg';//xori
		document['foto2'].src = 'piqcrs/pillow.gif';//xqiya
		document['foto3'].src = 'piqcrs/butterfly.jpg';//xixli	
		document['foto4'].src = 'piqcrs/lock.gif';//xala	
		document['foto5'].src = 'piqcrs/watermelon.gif';//xrbuj	
		document['foto6'].src = 'piqcrs/butterfly1.gif';//xixli
		document.getElementById('foto1lbl').innerHTML = 'Tori';
		document.getElementById('foto1lb2').innerHTML = 'Tkiya';
		document.getElementById('foto1lb3').innerHTML = 'TiTli';
		document.getElementById('foto1lb4').innerHTML = 'Tala';
		document.getElementById('foto1lb5').innerHTML = 'Trbuj';
		document.getElementById('foto1lb6').innerHTML = 'TiTli';
		break;
		case 20:
		document['foto1'].src = 'piqcrs/plate.jpg';//Xali
		document['foto2'].src = 'piqcrs/thurmus.jpg';//Xrms
		document['foto3'].src = 'piqcrs/bag.jpg';//Xela
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'Thali';
		document.getElementById('foto1lb2').innerHTML = 'Thrms';
		document.getElementById('foto1lb3').innerHTML = 'Thela';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 21:////wwwwwwwww
		document['foto1'].src = 'piqcrs/inkpot.jpg';//wvax
		document['foto2'].src = 'piqcrs/wall.jpg';//wivar
		document['foto3'].src = 'piqcrs/teeth.gif';//wax		
		document['foto4'].src = 'piqcrs/gloves.gif';//wsxane		
		document['foto5'].src = 'piqcrs/telescope.gif';//wurbIn		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'DvaT';
		document.getElementById('foto1lb2').innerHTML = 'Divar';
		document.getElementById('foto1lb3').innerHTML = 'DaT';
		document.getElementById('foto1lb4').innerHTML = 'DsTane';
		document.getElementById('foto1lb5').innerHTML = 'Durbin';		
		document.getElementById('foto1lb6').innerHTML = '';		
		break;
		case 22:////WWWWWWWWWW
		document['foto1'].src = 'piqcrs/bow.jpg';//WnuS
		document['foto2'].src = 'piqcrs/coriander.jpg';//qoriandr=Wniya
		document['foto3'].src = 'piqcrs/thread.jpg';//Waga		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'DhnuS';
		document.getElementById('foto1lb2').innerHTML = 'Dhniya';
		document.getElementById('foto1lb3').innerHTML = 'Dhaga';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';				
		document.getElementById('foto1lb6').innerHTML = '';				
		break;		
		case 23:
		document['foto1'].src = 'piqcrs/tap.gif';//nl
		document['foto2'].src = 'piqcrs/lemon.gif';//nimbu
		document['foto3'].src = 'piqcrs/coconut.jpg';//nariyl		
		document['foto4'].src = 'piqcrs/pear.gif';//naspxi		
		document['foto5'].src = 'piqcrs/boat.gif';//nav		
		document['foto6'].src = 'piqcrs/nurse.gif';//nrs
		document.getElementById('foto1lbl').innerHTML = 'nl';
		document.getElementById('foto1lb2').innerHTML = 'nimbu';
		document.getElementById('foto1lb3').innerHTML = 'nariyl';
		document.getElementById('foto1lb4').innerHTML = 'naspTi';
		document.getElementById('foto1lb5').innerHTML = 'nav';
		document.getElementById('foto1lb6').innerHTML = 'nrs';
		break;
		case 24:
		document['foto1'].src = 'piqcrs/thumb.jpg';//NguTa
		document['foto2'].src = 'piqcrs/ring.gif';//Nguthi
		document['foto3'].src = 'piqcrs/grapes.gif';//Ngur	
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'ANgutha';
		document.getElementById('foto1lb2').innerHTML = 'ANguthi';
		document.getElementById('foto1lb3').innerHTML = 'ANgur';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;		
		case 25:
		document['foto1'].src = 'piqcrs/onion.jpg';//pyaj		
		document['foto2'].src = 'piqcrs/feather.gif';//pNQ
		document['foto3'].src = 'piqcrs/foot.gif';//pAr
		document['foto4'].src = 'piqcrs/pencil.gif';//pAnsil
		document['foto5'].src = 'piqcrs/mint.jpg';//mint=puwina		
		document['foto6'].src = 'piqcrs/tree.gif';//peR
		document.getElementById('foto1lbl').innerHTML = 'pyaj';
		document.getElementById('foto1lb2').innerHTML = 'pNkh';
		document.getElementById('foto1lb3').innerHTML = 'pAer';
		document.getElementById('foto1lb4').innerHTML = 'pensil';
		document.getElementById('foto1lb5').innerHTML = 'puDina';
		document.getElementById('foto1lb6').innerHTML = 'perr';
		break;
		case 26:
		document['foto1'].src = 'piqcrs/fon.gif';//fon
		document['foto2'].src = 'piqcrs/folder.gif';//foldr
		document['foto3'].src = 'piqcrs/scale.gif';//futta		
		document['foto4'].src = 'piqcrs/flower.gif';//fuul		
		document['foto5'].src = 'piqcrs/freeze.gif';//friij		
		document['foto6'].src = 'piqcrs/shovel.gif';//favRa
		document.getElementById('foto1lbl').innerHTML = 'phon';
		document.getElementById('foto1lb2').innerHTML = 'pholdr';
		document.getElementById('foto1lb3').innerHTML = 'phutta';
		document.getElementById('foto1lb4').innerHTML = 'phul';
		document.getElementById('foto1lb5').innerHTML = 'phrij';
		document.getElementById('foto1lb6').innerHTML = 'phavrra';
		break;		
		case 27:
		document[ 'foto1' ].src = 'piqcrs/bus.gif';//bs
		document['foto2'].src = 'piqcrs/brush.gif';//brus
		document['foto3'].src = 'piqcrs/burger.gif';//brgr		
		document['foto4'].src = 'piqcrs/bread.gif';//brAd		
		document['foto5'].src = 'piqcrs/bottle.gif';//boxl	
		document['foto6'].src = 'piqcrs/drop.gif';//bunw
		document.getElementById('foto1lbl').innerHTML = 'bs';
		document.getElementById('foto1lb2').innerHTML = 'bruS';
		document.getElementById('foto1lb3').innerHTML = 'brgr';
		document.getElementById('foto1lb4').innerHTML = 'brAd';
		document.getElementById('foto1lb5').innerHTML = 'boTl';
		document.getElementById('foto1lb6').innerHTML = 'bunD';
		break;		
		case 28:
		document['foto1'].src = 'piqcrs/bear.jpg';//Balu
		document['foto2'].src = 'piqcrs/0.gif';
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'bhalu';
		document.getElementById('foto1lb2').innerHTML = '';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;		
		case 29:
		document['foto1'].src = 'piqcrs/fish.gif';//mCli
		document['foto2'].src = 'piqcrs/candle.gif';//mombxxi
		document['foto3'].src = 'piqcrs/mobile.gif';//mobail	
		document['foto4'].src = 'piqcrs/frog.gif';//mendk	
		document['foto5'].src = 'piqcrs/fist.gif';//mutTi		
		document['foto6'].src = 'piqcrs/groundnut.gif';//mufli
		document.getElementById('foto1lbl').innerHTML = 'mchhli';
		document.getElementById('foto1lb2').innerHTML = 'mombTTi';
		document.getElementById('foto1lb3').innerHTML = 'mobail';
		document.getElementById('foto1lb4').innerHTML = 'mendAk';
		document.getElementById('foto1lb5').innerHTML = 'mutthi';
		document.getElementById('foto1lb6').innerHTML = 'mufli';
		break;
		case 30:
		document['foto1'].src = 'piqcrs/yoga.jpg';//yoga
		document['foto2'].src = 'piqcrs/yoyo.gif';//yoyo
		document['foto3'].src = 'piqcrs/0.gif';		
		document['foto4'].src = 'piqcrs/0.gif';		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'yoga';
		document.getElementById('foto1lb2').innerHTML = 'yoyo';
		document.getElementById('foto1lb3').innerHTML = '';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 31:
		document['foto1'].src = 'piqcrs/razor.jpg';//rejr
		document['foto2'].src = 'piqcrs/rocket.gif';//roqet
		document['foto3'].src = 'piqcrs/rubber.gif';//rbR		
		document['foto4'].src = 'piqcrs/robot.gif';//robot
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'rezr';
		document.getElementById('foto1lb2').innerHTML = 'roket';
		document.getElementById('foto1lb3').innerHTML = 'rbrr';
		document.getElementById('foto1lb4').innerHTML = 'robot';
		document.getElementById('foto1lb5').innerHTML = '';		
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 32:
		document['foto1'].src = 'piqcrs/razor.jpg';//rejr
		document['foto2'].src = 'piqcrs/rocket.gif';//roqet
		document['foto3'].src = 'piqcrs/rubber.gif';//rbr		
		document['foto4'].src = 'piqcrs/robot.gif';//robot		
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'rejr';
		document.getElementById('foto1lb2').innerHTML = 'roket';
		document.getElementById('foto1lb3').innerHTML = 'rbrr';
		document.getElementById('foto1lb4').innerHTML = 'robot';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';		
		break;
		case 33:
		document['foto1'].src = 'piqcrs/top.jpg';//lttu
		document['foto2'].src = 'piqcrs/lighthouse.gif';//laithaus
		document['foto3'].src = 'piqcrs/lamp.gif';//lAmp	
		document['foto4'].src = 'piqcrs/envelope.gif';//lifafa		
		document['foto5'].src = 'piqcrs/garlic.gif';//lssun		
		document['foto6'].src = 'piqcrs/lantern.gif';//lalten
		document.getElementById('foto1lbl').innerHTML = 'lttu';
		document.getElementById('foto1lb2').innerHTML = 'laitHaus';
		document.getElementById('foto1lb3').innerHTML = 'lAmp';
		document.getElementById('foto1lb4').innerHTML = 'lifafa';
		document.getElementById('foto1lb5').innerHTML = 'lssun';
		document.getElementById('foto1lb6').innerHTML = 'lalten';
		break;
		case 34:
		document['foto1'].src = 'piqcrs/top.jpg';//lttu
		document['foto2'].src = 'piqcrs/lighthouse.gif';//laithaus
		document['foto3'].src = 'piqcrs/lamp.gif';//lemp	
		document['foto4'].src = 'piqcrs/envelope.gif';//lifafa		
		document['foto5'].src = 'piqcrs/garlic.gif';//lssun		
		document['foto6'].src = 'piqcrs/lantern.gif';//lalten
		document.getElementById('foto1lbl').innerHTML = 'lttu';
		document.getElementById('foto1lb2').innerHTML = 'laitHaus';
		document.getElementById('foto1lb3').innerHTML = 'lAmp';
		document.getElementById('foto1lb4').innerHTML = 'lifafa';
		document.getElementById('foto1lb5').innerHTML = 'lssun';
		document.getElementById('foto1lb6').innerHTML = 'lalten';
		break;
		case 35:
		document['foto1'].src = 'piqcrs/van.gif';//vAn
		document['foto2'].src = 'piqcrs/washbasin.gif';//vasbesin
		document['foto3'].src = 'piqcrs/washingmachine.gif';//vasingmsin	
		document['foto4'].src = 'piqcrs/waiter.gif';//vetr	
		document['foto5'].src = 'piqcrs/0.gif';		
		document['foto6'].src = 'piqcrs/0.gif';
		document.getElementById('foto1lbl').innerHTML = 'vAn';
		document.getElementById('foto1lb2').innerHTML = 'vasbesin';
		document.getElementById('foto1lb3').innerHTML = 'vasiNgmsin';
		document.getElementById('foto1lb4').innerHTML = 'vetr';
		document.getElementById('foto1lb5').innerHTML = '';			
		document.getElementById('foto1lb6').innerHTML = '';			
		break;
		case 36:
		document['foto1'].src = 'piqcrs/cycle.gif';//saiqil
		document['foto2'].src = 'piqcrs/sandwich.gif';//sendvic
		document['foto3'].src = 'piqcrs/sun.gif';//surAj		
		document['foto4'].src = 'piqcrs/pig.gif';//suAr		
		document['foto5'].src = 'piqcrs/whistle.gif';//siti		
		document['foto6'].src = 'piqcrs/ladder.gif';//siRi
		document.getElementById('foto1lbl').innerHTML = 'saikil';
		document.getElementById('foto1lb2').innerHTML = 'sAndvich';
		document.getElementById('foto1lb3').innerHTML = 'surAj';
		document.getElementById('foto1lb4').innerHTML = 'suAr';
		document.getElementById('foto1lb5').innerHTML = 'siti';
		document.getElementById('foto1lb6').innerHTML = 'sirri';
		break;
		case 37:
		document['foto1'].src = 'piqcrs/lion.gif';//Ser
		document['foto2'].src = 'piqcrs/sandwich.gif';//sndvic
		document['foto3'].src = 'piqcrs/turnip.jpg';//Slgm		
		document['foto4'].src = 'piqcrs/0.gif';//		
		document['foto5'].src = 'piqcrs/0.gif';//		
		document['foto6'].src = 'piqcrs/0.gif';//
		document.getElementById('foto1lbl').innerHTML = 'sher';
		document.getElementById('foto1lb2').innerHTML = 'sendvich';
		document.getElementById('foto1lb3').innerHTML = 'shlgm';
		document.getElementById('foto1lb4').innerHTML = '';
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;      
		case 38:
		document['foto1'].src = 'piqcrs/elephant.gif';//haXi
		document['foto2'].src = 'piqcrs/helicopter.gif';//heliqoptr
		document['foto3'].src = 'piqcrs/hanger.gif';//hengr		
		document['foto4'].src = 'piqcrs/horn.gif';//horn		
		document['foto5'].src = 'piqcrs/lips.gif';//hoT		
		document['foto6'].src = 'piqcrs/airbus.gif';//hvaijhaj
		document.getElementById('foto1lbl').innerHTML = 'HaThi';
		document.getElementById('foto1lb2').innerHTML = 'Helikoptr';
		document.getElementById('foto1lb3').innerHTML = 'HeNgr';
		document.getElementById('foto1lb4').innerHTML = 'Horn';
		document.getElementById('foto1lb5').innerHTML = 'HoT';		
		document.getElementById('foto1lb6').innerHTML = 'HvaijHaj';		
		break;      
	}
	//document.all['BGSOUND_ID'].src=arg + '.mp3';	
}
