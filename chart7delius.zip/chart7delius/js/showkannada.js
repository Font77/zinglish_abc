function showCharKannada(arg)
{//alert('showCharKannada(arg) '+arg);
	switch (arg)
	{
		case 1://AAAAAA
		document['foto1'].src = 'piqcrs/.jpg';//
		document['foto2'].src = 'piqcrs/.jpg';//ginger
		document['foto3'].src = 'piqcrs/egg.gif';//egg
		document['foto4'].src = 'piqcrs/pineapple.gif';//pineapple		
		document['foto5'].src = 'piqcrs/arrow.gif';//arrow
		document['foto6'].src = 'piqcrs/0.GIF';
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 2://aaaaaa
		document['foto1'].src = 'piqcrs/potato.jpg';//potato
		document['foto2'].src = 'piqcrs/0.GIF';
		document['foto3'].src = 'piqcrs/mango.jpg';//mango	
		document['foto4'].src = 'piqcrs/aK.gif';//eye	
		document['foto5'].src = 'piqcrs/icecream.gif';//icecream	
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = '';
		break;
		case 3:////iiiiii
		document['foto1'].src = 'piqcrs/tamarind.jpg';//imli
		document['foto2'].src = 'piqcrs/brick.jpg';//iit
		document['foto3'].src = 'piqcrs/sugarcane.jpg';//iiK
		document['foto4'].src = 'piqcrs/engine.jpg';//injn
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 4://////uuuuuuuuuu
		document['foto1'].src = 'piqcrs/owl.jpg';//ullu
		document['foto2'].src = 'piqcrs/camel1.jpg';//uut
		document['foto3'].src = 'piqcrs/camel2.gif';//uut	
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 5://///////eeeeeeeeee/
		document['foto1'].src = 'piqcrs/ladder.gif';//eni=ladder
		document['foto2'].src = 'piqcrs/0.GIF';
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 6://///oooooooo
		document['foto1'].src = 'piqcrs/camel.gif';//onte=camel
		document['foto2'].src = 'piqcrs/0.GIF';
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 7://////qqqqqqq
		document['foto1'].src = 'piqcrs/key.gif';//qan
		document['foto2'].src = 'piqcrs/qar.gif';//qar
		document['foto3'].src = 'piqcrs/qeq.gif';//qeq		
		document['foto4'].src = 'piqcrs/corn.jpg';//qoriandr=Kottambari		
		document['foto5'].src = 'piqcrs/cup.gif';//qp		
		document['foto6'].src = 'piqcrs/barber.jpg';//quxxa
		document.getElementById('foto1lbl').innerHTML = 'qiliqai'; 
		document.getElementById('foto1lb2').innerHTML = 'qar'; 
		document.getElementById('foto1lb3').innerHTML = 'qeq'; 
		document.getElementById('foto1lb4').innerHTML = 'qalu'; 
		document.getElementById('foto1lb5').innerHTML = 'qp';
		document.getElementById('foto1lb6').innerHTML = 'qsoriqa'; 
		break;		
		case 8://////QQQQQQQ
		document['foto1'].src = 'piqcrs/QrgoS.jpg';//QrgoS
		document['foto2'].src = 'piqcrs/QilaRi.gif';//QilaRi
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 9:////////gggggggg
		document['foto1'].src = 'piqcrs/throat.jpg';//gubbara
		document['foto2'].src = 'piqcrs/goBi.gif';//goBi
		document['foto3'].src = 'piqcrs/glob.gif';//glob		
		document['foto4'].src = 'piqcrs/gaRi.gif';//gaRi		
		document['foto5'].src = 'piqcrs/gay.gif';//gay	
		document['foto6'].src = 'piqcrs/gift.gif';//gift		
		document.getElementById('foto1lbl').innerHTML = 'gntlu'; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 10://////GGGGGGG
		document['foto1'].src = 'piqcrs/Gr.jpg';//Gr
		document['foto2'].src = 'piqcrs/GRi.gif';//GRi
		document['foto3'].src = 'piqcrs/GoRa.gif';//GoRa		
		document['foto4'].src = 'piqcrs/Giya.jpg';//Giya		
		document['foto5'].src = 'piqcrs/Gnti.gif';//Gnti		
		document['foto6'].src = 'piqcrs/Gosla.jpg';//Gosla		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 11:///////cccccccc
		document['foto1'].src = 'piqcrs/ceri.gif';//cherry
		document['foto2'].src = 'piqcrs/cppl.jpg';//sleeper
		document['foto3'].src = 'piqcrs/cabi.gif';//key		
		document['foto4'].src = 'piqcrs/ciRiya.gif';//sparrow		
		document['foto5'].src = 'piqcrs/cmmc.gif';//spoon		
		document['foto6'].src = 'piqcrs/0.GIF';//
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 12://///////CCCCCC
		document['foto1'].src = 'piqcrs/Cxri.gif';//Cxri
		document['foto2'].src = 'piqcrs/Cilqa.jpg';//Cilqa
		document['foto3'].src = 'piqcrs/CbRi.jpg';//CbRi		
		document['foto4'].src = 'piqcrs/CipAqli.jpg';//CipAqli
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;      
		case 13:////////jjjj
		document['foto1'].src = 'piqcrs/jug.gif';//jg
		document['foto2'].src = 'piqcrs/jacket.gif';//jqet
		document['foto3'].src = 'piqcrs/jeep.gif';//jiip		
		document['foto4'].src = 'piqcrs/jeans.gif';//jiins		
		document['foto5'].src = 'piqcrs/giraffe.gif';//jiraf		
		document['foto6'].src = 'piqcrs/judo.gif';//jal	
		document.getElementById('foto1lbl').innerHTML = 'jg'; 
		document.getElementById('foto1lb2').innerHTML = 'jAqet'; 
		document.getElementById('foto1lb3').innerHTML = 'jiip'; 
		document.getElementById('foto1lb4').innerHTML = 'jiins'; 
		document.getElementById('foto1lb5').innerHTML = 'jiraf';
		document.getElementById('foto1lb6').innerHTML = 'judo'; 
		break;	
		case 14://///JJJJJ
		document['foto1'].src = 'piqcrs/Jula.jpg';//Jula
		document['foto2'].src = 'piqcrs/Jrna.jpg';//Jrna
		document['foto3'].src = 'piqcrs/Jnda.jpg';//Jnda	
		document['foto4'].src = 'piqcrs/JopRi.jpg';//JopRi	
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';	
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 15://///tttttttttt
		document['foto1'].src = 'piqcrs/tshirt.jpg';//tshirt		
		document['foto2'].src = 'piqcrs/tub.gif';//tb
		document['foto3'].src = 'piqcrs/torch.gif';//torc
		document['foto4'].src = 'piqcrs/ticket.jpg';//tofi	
		document['foto5'].src = 'piqcrs/tyre.jpg';//topi	
		document['foto6'].src = 'piqcrs/tv.gif';//tivi				
		document.getElementById('foto1lbl').innerHTML = 'tiSrt'; 
		document.getElementById('foto1lb2').innerHTML = 'tb'; 
		document.getElementById('foto1lb3').innerHTML = 'torc'; 
		document.getElementById('foto1lb4').innerHTML = 'tiqt'; 
		document.getElementById('foto1lb5').innerHTML = 'tayr';
		document.getElementById('foto1lb6').innerHTML = 'tivi'; 
		break;	
		case 16://///TTTTTTT
		document['foto1'].src = 'piqcrs/TTera.jpg';//thathera
		document['foto2'].src = 'piqcrs/Tela.gif';//thela
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';				
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 17://///dddddddd
		document['foto1'].src = 'piqcrs/dumble.gif';//dmbl
		document['foto2'].src = 'piqcrs/desk.gif';//desq
		document['foto3'].src = 'piqcrs/dynasore.gif';//daynasor		
		document['foto4'].src = 'piqcrs/dancer.gif';//dancer=dansr		
		document['foto5'].src = 'piqcrs/drum.gif';//drum=drm		
		document['foto6'].src = 'piqcrs/dosa.jpg';	
		document.getElementById('foto1lbl').innerHTML = 'dmbl'; 
		document.getElementById('foto1lb2').innerHTML = 'desq'; 
		document.getElementById('foto1lb3').innerHTML = 'daynasor'; 
		document.getElementById('foto1lb4').innerHTML = 'dansr'; 
		document.getElementById('foto1lb5').innerHTML = 'drm';
		document.getElementById('foto1lb6').innerHTML = 'dosa'; 
		break;		
		case 18://////DDDDDDD
		document['foto1'].src = 'piqcrs/Dkkn.jpg';//dhakkan
		document['foto2'].src = 'piqcrs/0.GIF';
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 19://////xxxxxxxx
		document['foto1'].src = 'piqcrs/xori.jpg';//xori
		document['foto2'].src = 'piqcrs/xqiya.gif';//xqiya
		document['foto3'].src = 'piqcrs/xixli.jpg';//xixli	
		document['foto4'].src = 'piqcrs/xala.gif';//xala	
		document['foto5'].src = 'piqcrs/xrbuj.gif';//xrbuj	
		document['foto6'].src = 'piqcrs/xixli.gif';//xixli		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 20:////XXXXXXX
		document['foto1'].src = 'piqcrs/Xali.jpg';//Xali
		document['foto2'].src = 'piqcrs/Xrms.jpg';//Xrms
		document['foto3'].src = 'piqcrs/Xela.jpg';//Xela
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 21:///////wwwwwwwww
		document['foto1'].src = 'piqcrs/pomegranate.jpg';//pomegranate=waLimbe
		document['foto2'].src = 'piqcrs/wivar.jpg';//wivar
		document['foto3'].src = 'piqcrs/wax.gif';//wax		
		document['foto4'].src = 'piqcrs/wsxane.gif';//wsxane		
		document['foto5'].src = 'piqcrs/wurbiin.gif';//wurbiin		
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = 'waLimbe'; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 22://///////WWWWWWWWW
		document['foto1'].src = 'piqcrs/WnuS.jpg';//WnuS
		document['foto2'].src = 'piqcrs/Wniya.jpg';//Wniya
		document['foto3'].src = 'piqcrs/Waga.jpg';//Waga		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';				
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 23:////////////nnnnnnnnn
		document['foto1'].src = 'piqcrs/nl.gif';//nl
		document['foto2'].src = 'piqcrs/nimbu.gif';//nimbu
		document['foto3'].src = 'piqcrs/nariyl.jpg';//nariyl		
		document['foto4'].src = 'piqcrs/naspxi.gif';//naspxi		
		document['foto5'].src = 'piqcrs/nailpolish.jpg';//nav		
		document['foto6'].src = 'piqcrs/nrs.gif';//nrs			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = 'nelpolis';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 24:///////////NNNNNNNNNNN
		document['foto1'].src = 'piqcrs/NguTa.jpg';//NguTa
		document['foto2'].src = 'piqcrs/NguTi.gif';//Nguthi
		document['foto3'].src = 'piqcrs/Ngur.gif';//Ngur	
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 25:////////pppppppp
		document['foto1'].src = 'piqcrs/pencil.gif';//pyaj		
		document['foto2'].src = 'piqcrs/pipe.jpg';//pNQ
		document['foto3'].src = 'piqcrs/plate.jpg';//pAr
		document['foto4'].src = 'piqcrs/police.gif';//pAnsil
		document['foto5'].src = 'piqcrs/pant.gif';//pAnt		
		document['foto6'].src = 'piqcrs/pizza2.gif';//peR			
		document.getElementById('foto1lbl').innerHTML = 'pAnsil'; 
		document.getElementById('foto1lb2').innerHTML = 'paip'; 
		document.getElementById('foto1lb3').innerHTML = 'plet'; 
		document.getElementById('foto1lb4').innerHTML = 'pulis'; 
		document.getElementById('foto1lb5').innerHTML = 'pAnt';
		document.getElementById('foto1lb6').innerHTML = 'pijja'; 
		break;
		case 26://///fffffffff
		document['foto1'].src = 'piqcrs/fon.gif';//fon
		document['foto2'].src = 'piqcrs/foldr.gif';//foldr
		document['foto3'].src = 'piqcrs/futta.gif';//futta		
		document['foto4'].src = 'piqcrs/fuul.gif';//fuul		
		document['foto5'].src = 'piqcrs/friij.gif';//friij		
		document['foto6'].src = 'piqcrs/favRa.gif';//favRa	
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 27:///////bbbbbbbbb
		document[ 'foto1' ].src = 'piqcrs/bus.gif';//bs
		document['foto2'].src = 'piqcrs/brush.gif';//brus
		document['foto3'].src = 'piqcrs/burger.gif';//brgr		
		document['foto4'].src = 'piqcrs/bread.gif';//brAd		
		document['foto5'].src = 'piqcrs/bottle.gif';//boxl	
		document['foto6'].src = 'piqcrs/shirtbutton.jpg';//bunw		
		document.getElementById('foto1lbl').innerHTML = 'bs'; 
		document.getElementById('foto1lb2').innerHTML = 'brus'; 
		document.getElementById('foto1lb3').innerHTML = 'brgr'; 
		document.getElementById('foto1lb4').innerHTML = 'brAd'; 
		document.getElementById('foto1lb5').innerHTML = 'botl';
		document.getElementById('foto1lb6').innerHTML = 'btn'; 
		break;		
		case 28:////////BBBBBBBBB
		document['foto1'].src = 'piqcrs/Balu.jpg';//Balu
		document['foto2'].src = 'piqcrs/0.GIF';
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;		
		case 29://////mmmmmmm
		document['foto1'].src = 'piqcrs/mCli.gif';//mCli
		document['foto2'].src = 'piqcrs/mombxxi.gif';//mombxxi
		document['foto3'].src = 'piqcrs/mobail.gif';//mobail	
		document['foto4'].src = 'piqcrs/mendk.gif';//mendk	
		document['foto5'].src = 'piqcrs/mutTi.gif';//mutTi		
		document['foto6'].src = 'piqcrs/mufli.gif';//mufli		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 30://///yyyyyyyyy
		document['foto1'].src = 'piqcrs/yoga.jpg';//yoga
		document['foto2'].src = 'piqcrs/yoyo.gif';//yoyo
		document['foto3'].src = 'piqcrs/0.GIF';		
		document['foto4'].src = 'piqcrs/0.GIF';		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 31:///////rrrrrrrrrr
		document['foto1'].src = 'piqcrs/rejr.jpg';//rejr
		document['foto2'].src = 'piqcrs/roqet.gif';//roqet
		document['foto3'].src = 'piqcrs/rbR.gif';//rbR		
		document['foto4'].src = 'piqcrs/robot.gif';//robot
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 32:////RRRRRR
		document['foto1'].src = 'piqcrs/rejr.jpg';//rejr
		document['foto2'].src = 'piqcrs/roqet.gif';//roqet
		document['foto3'].src = 'piqcrs/rbR.gif';//rbr		
		document['foto4'].src = 'piqcrs/robot.gif';//robot		
		document['foto5'].src = 'piqcrs/0.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 33:///////lllllll
		document['foto1'].src = 'piqcrs/lttu.jpg';//lttu
		document['foto2'].src = 'piqcrs/laithaus.gif';//laithaus
		document['foto3'].src = 'piqcrs/lemp.gif';//lemp	
		document['foto4'].src = 'piqcrs/lion.gif';//lifafa		
		document['foto5'].src = 'piqcrs/lssun.gif';//lssun		
		document['foto6'].src = 'piqcrs/lalten.gif';//lalten			
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = 'layn'; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 34:///////LLLLLLLL
		document['foto1'].src = 'piqcrs/lttu.jpg';//lttu
		document['foto2'].src = 'piqcrs/laithaus.gif';//laithaus
		document['foto3'].src = 'piqcrs/lemp.gif';//lemp	
		document['foto4'].src = 'piqcrs/lifafa.gif';//lifafa		
		document['foto5'].src = 'piqcrs/lssun.gif';//lssun		
		document['foto6'].src = 'piqcrs/lalten.gif';//lalten	
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 35:///////vvvvvvvvv
		document['foto1'].src = 'piqcrs/vAn.gif';//vAn
		document['foto2'].src = 'piqcrs/washbasin.gif';//vasbesin
		document['foto3'].src = 'piqcrs/washingmachine.gif';//vasingmsin	
		document['foto4'].src = 'piqcrs/vetr.gif';//vetr	
		document['foto5'].src = 'piqcrs/airbus.GIF';		
		document['foto6'].src = 'piqcrs/0.GIF';			
		document.getElementById('foto1lbl').innerHTML = 'vAn'; 
		document.getElementById('foto1lb2').innerHTML = 'vasbesin'; 
		document.getElementById('foto1lb3').innerHTML = 'vasingmsin'; 
		document.getElementById('foto1lb4').innerHTML = 'vetr'; 
		document.getElementById('foto1lb5').innerHTML = 'vimana';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 36://////sssssss
		document['foto1'].src = 'piqcrs/surya.gif';//saiqil
		document['foto2'].src = 'piqcrs/sndvic.gif';//sndvic
		document['foto3'].src = 'piqcrs/ginger.gif';//sunTi		
		document['foto4'].src = 'piqcrs/groundnut.gif';//		
		document['foto5'].src = 'piqcrs/siiti.gif';//siiti		
		document['foto6'].src = 'piqcrs/siRi.gif';//siRi
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = 'sunTi'; 
		document.getElementById('foto1lb4').innerHTML = 'seNga'; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;
		case 37://////SSSSSSS
		document['foto1'].src = 'piqcrs/saiqil.gif';//saiqil
		document['foto2'].src = 'piqcrs/sndvic.gif';//sndvic
		document['foto3'].src = 'piqcrs/surj.gif';//surj		
		document['foto4'].src = 'piqcrs/suAr.gif';//suAr		
		document['foto5'].src = 'piqcrs/siiti.gif';//siiti		
		document['foto6'].src = 'piqcrs/siRi.gif';//siRi
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = ''; 
		break;      
		case 38://////hhhhhhhh
		document['foto1'].src = 'piqcrs/hani.gif';//hani=drop
		document['foto2'].src = 'piqcrs/handi.gif';//handi=pig
		document['foto3'].src = 'piqcrs/heNgr.gif';//heNgr		
		document['foto4'].src = 'piqcrs/horn.gif';//horn		
		document['foto5'].src = 'piqcrs/hoT.gif';//hoT		
		document['foto6'].src = 'piqcrs/hare.jpg';//hvaijhaj		
		document.getElementById('foto1lbl').innerHTML = ''; 
		document.getElementById('foto1lb2').innerHTML = ''; 
		document.getElementById('foto1lb3').innerHTML = ''; 
		document.getElementById('foto1lb4').innerHTML = ''; 
		document.getElementById('foto1lb5').innerHTML = '';
		document.getElementById('foto1lb6').innerHTML = 'mola'; 
		break;      
	}
	//document.all['BGSOUND_ID'].src=arg + '.mp3';	
}