function showNmbrs(arg)
{
	document['foto1'].src = '0.gif';
	switch (arg)
	{
		case 1: document['foto1'].src = '0.gif';break;
		case 2: document['foto1'].src = 'n1.gif';break;
		case 3: document['foto1'].src = 'n2.gif';break;
		case 4: document['foto1'].src = 'n3.gif';break;
		case 7: document['foto1'].src = 'n4.gif';break;
		case 8: document['foto1'].src = 'n5.gif';break;
		case 9: document['foto1'].src = 'n6.gif';break;
		case 10: document['foto1'].src = 'n7.gif';break;
		case 13: document['foto1'].src = 'n8.gif';break;
		case 14: document['foto1'].src = 'n9.gif';break;
		case 15: document['foto1'].src = 'n10.gif';break;
		case 16: document['foto1'].src = 'n11.gif';break;
		case 19: document['foto1'].src = 'n12.gif';break;
		case 20: document['foto1'].src = 'n13.gif';break;
		case 21: document['foto1'].src = 'n14.gif';break;
		case 22: document['foto1'].src = 'n15.gif';break;
	}
	document['foto2'].src = '0.gif';
	document['foto3'].src = '0.gif';
	document['foto4'].src = '0.gif';
	document['foto5'].src = '0.gif';
	document['foto6'].src = '0.gif';
}
