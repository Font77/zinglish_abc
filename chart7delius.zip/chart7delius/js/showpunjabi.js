function showCharPunjabi(arg)
{//alert('showCharTelugu(arg) '+arg);
	switch (arg)
	{
		case 1:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.gif';		
		document['foto4'].src = '4.gif';		
		document['foto5'].src = '173.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 2:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.gif';		
		document['foto5'].src = '147.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 3:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 4:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 5:
		document['foto1'].src = '38.gif';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 6:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 7:
		document['foto1'].src = '75.gif';
		document['foto2'].src = '76.gif';
		document['foto3'].src = '79.gif';		
		document['foto4'].src = '80.gif';		
		document['foto5'].src = '89.gif';		
		document['foto6'].src = '93.gif';		
		break;		
		case 8:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 9:
		document['foto1'].src = '52.gif';
		document['foto2'].src = '53.gif';
		document['foto3'].src = '54.gif';		
		document['foto4'].src = '44.gif';		
		document['foto5'].src = '47.gif';		
		document['foto6'].src = '56.gif';		
		break;
		case 10:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.gif';
		document['foto3'].src = '57.gif';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.gif';		
		document['foto6'].src = '234.jpg';			
		break;
		case 11:
		document['foto1'].src = '22.gif';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.gif';		
		document['foto4'].src = '25.gif';		
		document['foto5'].src = '23.gif';		
		document['foto6'].src = '0.GIF';			
		break;
		case 12:
		document['foto1'].src = '24.gif';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;      
		case 13:
		document['foto1'].src = '67.gif';
		document['foto2'].src = '69.gif';
		document['foto3'].src = '70.gif';		
		document['foto4'].src = '71.gif';		
		document['foto5'].src = '74.gif';		
		document['foto6'].src = '72.gif';	
		break;	
		case 14:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;		
		case 15:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.gif';
		document['foto2'].src = '169.gif';
		document['foto3'].src = '171.gif';		
		document['foto4'].src = '164.gif';		
		document['foto5'].src = '170.gif';				
		break;	
		case 16:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 17:
		document['foto1'].src = '29.gif';
		document['foto2'].src = '30.gif';
		document['foto3'].src = '31.gif';		
		document['foto4'].src = '32.gif';		
		document['foto5'].src = '34.gif';		
		document['foto6'].src = '39.gif';	
		break;		
		case 18:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 19:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.gif';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.gif';		
		document['foto5'].src = '160.gif';		
		document['foto6'].src = '163.gif';		
		break;
		case 20:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 21:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.gif';		
		document['foto4'].src = '40.gif';		
		document['foto5'].src = '167.gif';		
		document['foto6'].src = '0.GIF';		
		break;
		case 22:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';				
		break;		
		case 23:
		document['foto1'].src = '184.gif';
		document['foto2'].src = '113.gif';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.gif';		
		document['foto5'].src = '110.gif';		
		document['foto6'].src = '115.gif';			
		break;
		case 24:
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.gif';
		document['foto3'].src = '114.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		break;		
		case 25:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.gif';
		document['foto3'].src = '121.gif';
		document['foto4'].src = '120.gif';
		document['foto5'].src = '119.gif';		
		document['foto6'].src = '118.gif';			
		break;
		case 26:
		document['foto1'].src = '49.gif';
		document['foto2'].src = '48.gif';
		document['foto3'].src = '43.gif';		
		document['foto4'].src = '42.gif';		
		document['foto5'].src = '41.gif';		
		document['foto6'].src = '37.gif';		
		break;		
		case 27:
		document[ 'foto1' ].src = '12.gif';
		document['foto2'].src = '13.gif';
		document['foto3'].src = '14.gif';		
		document['foto4'].src = '15.gif';		
		document['foto5'].src = '16.gif';		
		document['foto6'].src = '20.gif';			
		break;		
		case 28:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;		
		case 29:
		document['foto1'].src = '99.gif';
		document['foto2'].src = '103.gif';
		document['foto3'].src = '104.gif';		
		document['foto4'].src = '106.gif';		
		document['foto5'].src = '109.gif';		
		document['foto6'].src = '101.gif';			
		break;
		case 30:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 31:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		break;
		case 32:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 33:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';			
		break;
		case 34:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';
		break;
		case 35:
		document['foto1'].src = '44.gif';
		document['foto2'].src = '151.gif';
		document['foto3'].src = '175.gif';		
		document['foto4'].src = '176.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';			
		break;
		case 36:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;
		case 37:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		break;      
		case 38:
		document['foto1'].src = '59.gif';
		document['foto2'].src = '62.gif';
		document['foto3'].src = '63.gif';		
		document['foto4'].src = '64.gif';		
		document['foto5'].src = '65.gif';		
		document['foto6'].src = '66.gif';		
		break;      
	}
	document.all['BGSOUND_ID'].src=arg + '.mp3';	
}
//var previousarg=0;
var isPrevSpaceMatraVovel = 1;
function completeCharHindi(arg)
{
	switch (arg)
	{
		case 255://alert("playChar vith 255");
		case 128: case 0:
		document['foto1'].src = '0.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';		
		document.all['BGSOUND_ID'].src='1.mp3';
		break;
		case 156:
		document['foto1'].src = '0.GIF';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='1.mp3';
		break;			
		case 129:
		document['foto1'].src = '222.jpg';
		document['foto2'].src = '223.jpg';
		document['foto3'].src = '3.gif';		
		document['foto4'].src = '4.gif';		
		document['foto5'].src = '173.gif';		
		document['foto6'].src = '0.GIF';
		ta1.value += "\u0905";
		document.all['BGSOUND_ID'].src='1.mp3';
		break;
		case 144:
		document['foto1'].src = '204.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '205.jpg';		
		document['foto4'].src = '146.gif';		
		document['foto5'].src = '147.gif';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='2.mp3';		
		break;
		case 192:
		document['foto1'].src = '203.jpg';
		document['foto2'].src = '214.jpg';
		document['foto3'].src = '215.jpg';		
		document['foto4'].src = '188.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='3.mp3';		
		break;
		case 136:
		document['foto1'].src = '225.jpg';
		document['foto2'].src = '224.jpg';
		document['foto3'].src = '174.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='4.mp3';	
		break;
		case 130:
		document['foto1'].src = '38.gif';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='5.mp3';		
		break;
		case 160:
		document['foto1'].src = '213.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='6.mp3';	
		break;
		case 10://NN
		document['foto1'].src = '193.jpg';
		document['foto2'].src = '5.gif';
		document['foto3'].src = '114.gif';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='7.mp3';				
		break;		
		case 193: //boks 8
		document['foto1'].src = '75.gif';
		document['foto2'].src = '76.gif';
		document['foto3'].src = '79.gif';		
		document['foto4'].src = '80.gif';		
		document['foto5'].src = '89.gif';		
		document['foto6'].src = '93.gif';
		document.all['BGSOUND_ID'].src='8.mp3';		
		break;
		case 65:
		document['foto1'].src = '185.jpg';
		document['foto2'].src = '186.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='9.mp3';				
		break;
		case 164:
		document['foto1'].src = '52.gif';
		document['foto2'].src = '53.gif';
		document['foto3'].src = '54.gif';		
		document['foto4'].src = '44.gif';		
		document['foto5'].src = '47.gif';		
		document['foto6'].src = '56.gif';
		document.all['BGSOUND_ID'].src='10.mp3';			
		break;
		case 36:
		document['foto1'].src = '221.jpg';
		document['foto2'].src = '50.gif';
		document['foto3'].src = '57.gif';		
		document['foto4'].src = '183.jpg';		
		document['foto5'].src = '58.gif';		
		document['foto6'].src = '234.jpg';
		document.all['BGSOUND_ID'].src='11.mp3';		
		break;
		case 18:
		document['foto1'].src = '0.gif';
		document['foto2'].src = '0.gif';
		document['foto3'].src = '0.gif';		
		document['foto4'].src = '0.gif';		
		document['foto5'].src = '0.gif';		
		document['foto6'].src = '0.gif';
		document.all['BGSOUND_ID'].src='12.mp3';		
		break;			
		case 224:
		document['foto1'].src = '22.gif';
		document['foto2'].src = '207.jpg';
		document['foto3'].src = '21.gif';		
		document['foto4'].src = '25.gif';		
		document['foto5'].src = '23.gif';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='13.mp3';			
		break;	
		case 96:
		document['foto1'].src = '24.gif';
		document['foto2'].src = '226.jpg';
		document['foto3'].src = '227.jpg';		
		document['foto4'].src = '228.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='14.mp3';			
		break;		
		case 176:
		document['foto1'].src = '67.gif';
		document['foto2'].src = '69.gif';
		document['foto3'].src = '70.gif';		
		document['foto4'].src = '71.gif';		
		document['foto5'].src = '74.gif';		
		document['foto6'].src = '72.gif';
		document.all['BGSOUND_ID'].src='15.mp3';			
		break;	
		case 48:
		document['foto1'].src = '217.jpg';
		document['foto2'].src = '218.jpg';
		document['foto3'].src = '219.jpg';		
		document['foto4'].src = '220.jpg';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='16.mp3';			
		break;		
		case 132:
		document['foto1'].src = '233.jpg';			
		document['foto6'].src = '166.gif';
		document['foto2'].src = '169.gif';
		document['foto3'].src = '171.gif';		
		document['foto4'].src = '164.gif';		
		document['foto5'].src = '170.gif';
		document.all['BGSOUND_ID'].src='17.mp3';		
		break;		
		case 4:
		document['foto1'].src = '201.jpg';
		document['foto2'].src = '135.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='18.mp3';			
		break;
		case 152:
		document['foto1'].src = '29.gif';
		document['foto2'].src = '30.gif';
		document['foto3'].src = '31.gif';		
		document['foto4'].src = '32.gif';		
		document['foto5'].src = '34.gif';		
		document['foto6'].src = '39.gif';
		document.all['BGSOUND_ID'].src='19.mp3';	
		break;
		case 24:
		document['foto1'].src = '197.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='20.mp3';		
		break;
		case 145:
		document['foto1'].src = '216.jpg';
		document['foto2'].src = '158.gif';
		document['foto3'].src = '195.jpg';		
		document['foto4'].src = '159.gif';		
		document['foto5'].src = '160.gif';		
		document['foto6'].src = '163.gif';
		document.all['BGSOUND_ID'].src='21.mp3';	
		break;
		case 17:
		document['foto1'].src = '191.jpg';
		document['foto2'].src = '192.jpg';
		document['foto3'].src = '212.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='22.mp3';		
		break;		
		case 133:
		document['foto1'].src = '189.jpg';
		document['foto2'].src = '190.jpg';
		document['foto3'].src = '26.gif';		
		document['foto4'].src = '40.gif';		
		document['foto5'].src = '167.gif';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='23.mp3';		
		break;
		case 5:
		document['foto1'].src = '211.jpg';
		document['foto2'].src = '210.jpg';
		document['foto3'].src = '209.jpg';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='24.mp3';	
		break;		
		case 138:
		document['foto1'].src = '184.gif';
		document['foto2'].src = '113.gif';
		document['foto3'].src = '182.jpg';		
		document['foto4'].src = '111.gif';		
		document['foto5'].src = '110.gif';		
		document['foto6'].src = '115.gif';
		document.all['BGSOUND_ID'].src='25.mp3';		
		break;
		case 131:
		document['foto1'].src = '202.jpg';			
		document['foto2'].src = '116.gif';
		document['foto3'].src = '121.gif';
		document['foto4'].src = '120.gif';
		document['foto5'].src = '119.gif';		
		document['foto6'].src = '118.gif';
		document.all['BGSOUND_ID'].src='26.mp3';	
		break;		
		case 135:
		document['foto1'].src = '49.gif';
		document['foto2'].src = '48.gif';
		document['foto3'].src = '43.gif';		
		document['foto4'].src = '42.gif';		
		document['foto5'].src = '41.gif';		
		document['foto6'].src = '37.gif';
		document.all['BGSOUND_ID'].src='27.mp3';	
		break;		
		case 140:
		document[ 'foto1' ].src = '12.gif';
		document['foto2'].src = '13.gif';
		document['foto3'].src = '14.gif';		
		document['foto4'].src = '15.gif';		
		document['foto5'].src = '16.gif';		
		document['foto6'].src = '20.gif';
		document.all['BGSOUND_ID'].src='28.mp3';	
		break;		
		case 12:
		document['foto1'].src = '196.jpg';
		document['foto2'].src = '0.GIF';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='29.mp3';		
		break;
		case 161:
		document['foto1'].src = '99.gif';
		document['foto2'].src = '103.gif';
		document['foto3'].src = '104.gif';		
		document['foto4'].src = '106.gif';		
		document['foto5'].src = '109.gif';		
		document['foto6'].src = '101.gif';
		document.all['BGSOUND_ID'].src='30.mp3';	
		break;
		case 200:
		document['foto1'].src = '198.jpg';
		document['foto2'].src = '177.gif';
		document['foto3'].src = '0.GIF';		
		document['foto4'].src = '0.GIF';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='31.mp3';	
		break;
		case 146:
		document['foto1'].src = '230.jpg';
		document['foto2'].src = '137.gif';
		document['foto3'].src = '133.gif';		
		document['foto4'].src = '136.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='32.mp3';	
		break;
		case 162:
		document['foto1'].src = '208.jpg';
		document['foto2'].src = '98.gif';
		document['foto3'].src = '94.gif';		
		document['foto4'].src = '95.gif';		
		document['foto5'].src = '96.gif';		
		document['foto6'].src = '97.gif';
		document.all['BGSOUND_ID'].src='33.mp3';			
		break;
		case 168:
		document['foto1'].src = '44.gif';
		document['foto2'].src = '151.gif';
		document['foto3'].src = '175.gif';		
		document['foto4'].src = '176.gif';		
		document['foto5'].src = '0.GIF';		
		document['foto6'].src = '0.GIF';
		document.all['BGSOUND_ID'].src='34.mp3';		
		break;
		case 196:
		document['foto1'].src = '138.gif';
		document['foto2'].src = '139.gif';
		document['foto3'].src = '157.gif';		
		document['foto4'].src = '156.gif';		
		document['foto5'].src = '152.gif';		
		document['foto6'].src = '149.gif';
		document.all['BGSOUND_ID'].src='35.mp3';		
		break;
		case 137:
		document['foto1'].src = '59.gif';
		document['foto2'].src = '62.gif';
		document['foto3'].src = '63.gif';		
		document['foto4'].src = '64.gif';		
		document['foto5'].src = '65.gif';		
		document['foto6'].src = '66.gif';
		document.all['BGSOUND_ID'].src='36.mp3';	
		break;
	}
	//previousarg=arg;
}